
  # School Management System UI/UX

  This is a code bundle for School Management System UI/UX. The original project is available at https://www.figma.com/design/fIakXXxwKvi5QeTX7TJEA5/School-Management-System-UI-UX.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  