import React, { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'administrator' | 'teacher' | 'parent' | 'bursar' | 'inventory';

export type StudentStatus = 'Active' | 'Transferred' | 'Expelled' | 'Alumni' | 'Archived';

export interface Student {
  id: string;
  admissionNumber: string;
  firstName: string;
  lastName: string;
  otherNames?: string;
  grade: string;
  stream?: string;
  photoUrl?: string;
  dateOfBirth: string;
  gender: 'Male' | 'Female';
  parentName: string;
  parentPhone: string;
  parentEmail: string;
  status: StudentStatus;
  medicalInfo?: string;
  birthCertificateUrl?: string;
  admissionDate: string;
  archived?: boolean;
  archivedDate?: string;
  archivedBy?: string;
  transferReason?: string;
  documents?: Document[];
  historyTimeline?: HistoryEvent[];
}

export interface Document {
  id: string;
  name: string;
  type: string;
  url: string;
  uploadedDate: string;
  uploadedBy: string;
}

export interface HistoryEvent {
  id: string;
  date: string;
  event: string;
  description: string;
  performedBy: string;
}

export interface Teacher {
  id: string;
  firstName: string;
  lastName: string;
  tscNumber: string;
  email: string;
  phone: string;
  subjects: string[];
  employmentStatus: 'Active' | 'On Leave' | 'Terminated';
  photoUrl?: string;
}

export interface Asset {
  id: string;
  name: string;
  category: string;
  serialNumber?: string;
  purchaseDate: string;
  condition: 'Excellent' | 'Good' | 'Fair' | 'Poor';
  assignedLocation: string;
  purchasePrice: number;
  currentValue: number;
}

export interface FeeRecord {
  id: string;
  studentId: string;
  term: string;
  year: string;
  totalFees: number;
  paidAmount: number;
  balance: number;
  payments: Payment[];
}

export interface Payment {
  id: string;
  date: string;
  amount: number;
  method: 'Cash' | 'M-Pesa' | 'Bank Transfer' | 'Cheque';
  reference?: string;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  date: string;
  status: 'Present' | 'Absent' | 'Late' | 'Excused';
  reason?: string;
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  date: string;
  priority: 'low' | 'medium' | 'high' | 'emergency';
  targetRoles: UserRole[];
  author: string;
}

export interface AcademicTerm {
  id: string;
  name: string;
  year: string;
  startDate: string;
  endDate: string;
  isCurrent: boolean;
}

export interface ExamSchedule {
  id: string;
  subject: string;
  grade: string;
  date: string;
  time: string;
  duration: string;
}

export interface Message {
  id: string;
  type: 'sms' | 'email';
  recipient: string;
  subject?: string;
  content: string;
  sentDate: string;
  status: 'pending' | 'sent' | 'failed' | 'delivered';
  sentBy: string;
}

export interface AuditLog {
  id: string;
  user: string;
  action: string;
  record: string;
  date: string;
  time: string;
  details?: string;
}

export interface ExamResult {
  id: string;
  studentId: string;
  term: string;
  year: string;
  grade: string;
  learningAreas: LearningArea[];
  teacherRemarks?: string;
  principalRemarks?: string;
  generatedDate?: string;
}

export interface LearningArea {
  name: string;
  score: number;
  grade: string;
  competency: string;
}

interface AppContextType {
  currentUser: { role: UserRole; name: string; lastLogin?: string } | null;
  setCurrentUser: (user: { role: UserRole; name: string; lastLogin?: string } | null) => void;
  currentView: string;
  setCurrentView: (view: string) => void;
  students: Student[];
  addStudent: (student: Student) => void;
  updateStudent: (id: string, student: Partial<Student>) => void;
  deleteStudent: (id: string) => void;
  archiveStudent: (id: string, reason?: string) => void;
  restoreStudent: (id: string) => void;
  teachers: Teacher[];
  assets: Asset[];
  addAsset: (asset: Asset) => void;
  updateAsset: (id: string, asset: Partial<Asset>) => void;
  feeRecords: FeeRecord[];
  attendanceRecords: AttendanceRecord[];
  addAttendanceRecord: (record: AttendanceRecord) => void;
  announcements: Announcement[];
  academicTerms: AcademicTerm[];
  examSchedules: ExamSchedule[];
  messages: Message[];
  sendMessage: (message: Message) => void;
  auditLogs: AuditLog[];
  addAuditLog: (log: AuditLog) => void;
  examResults: ExamResult[];
  addExamResult: (result: ExamResult) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

// Mock data
const mockStudents: Student[] = [
  {
    id: '1',
    admissionNumber: 'TKA2024001',
    firstName: 'John',
    lastName: 'Kamau',
    otherNames: 'Mwangi',
    grade: 'Grade 3',
    stream: 'A',
    dateOfBirth: '2015-03-15',
    gender: 'Male',
    parentName: 'Peter Kamau',
    parentPhone: '+254712345678',
    parentEmail: 'pkamau@example.com',
    status: 'Active',
    admissionDate: '2024-01-15',
  },
  {
    id: '2',
    admissionNumber: 'TKA2024002',
    firstName: 'Mary',
    lastName: 'Wanjiru',
    grade: 'Grade 5',
    stream: 'B',
    dateOfBirth: '2013-07-22',
    gender: 'Female',
    parentName: 'Sarah Wanjiru',
    parentPhone: '+254723456789',
    parentEmail: 'swanjiru@example.com',
    status: 'Active',
    admissionDate: '2024-01-15',
  },
  {
    id: '3',
    admissionNumber: 'TKA2024003',
    firstName: 'David',
    lastName: 'Omondi',
    grade: 'Grade 6',
    stream: 'A',
    dateOfBirth: '2012-11-10',
    gender: 'Male',
    parentName: 'James Omondi',
    parentPhone: '+254734567890',
    parentEmail: 'jomondi@example.com',
    status: 'Active',
    admissionDate: '2024-01-15',
  },
];

const mockTeachers: Teacher[] = [
  {
    id: '1',
    firstName: 'Grace',
    lastName: 'Njeri',
    tscNumber: 'TSC123456',
    email: 'gnjeri@threekings.ac.ke',
    phone: '+254745678901',
    subjects: ['Mathematics', 'Science'],
    employmentStatus: 'Active',
  },
  {
    id: '2',
    firstName: 'Michael',
    lastName: 'Otieno',
    tscNumber: 'TSC234567',
    email: 'motieno@threekings.ac.ke',
    phone: '+254756789012',
    subjects: ['English', 'Kiswahili'],
    employmentStatus: 'Active',
  },
];

const mockAssets: Asset[] = [
  {
    id: '1',
    name: 'HP LaserJet Printer',
    category: 'Office Equipment',
    serialNumber: 'HP12345678',
    purchaseDate: '2023-05-15',
    condition: 'Good',
    assignedLocation: 'Main Office',
    purchasePrice: 45000,
    currentValue: 38000,
  },
  {
    id: '2',
    name: 'Smart Board',
    category: 'Teaching Equipment',
    serialNumber: 'SB87654321',
    purchaseDate: '2023-08-20',
    condition: 'Excellent',
    assignedLocation: 'Grade 5 Classroom',
    purchasePrice: 120000,
    currentValue: 110000,
  },
];

const mockFeeRecords: FeeRecord[] = [
  {
    id: '1',
    studentId: '1',
    term: 'Term 1',
    year: '2024',
    totalFees: 35000,
    paidAmount: 35000,
    balance: 0,
    payments: [
      {
        id: 'p1',
        date: '2024-01-20',
        amount: 35000,
        method: 'M-Pesa',
        reference: 'QAB1234XYZ',
      },
    ],
  },
  {
    id: '2',
    studentId: '2',
    term: 'Term 1',
    year: '2024',
    totalFees: 35000,
    paidAmount: 20000,
    balance: 15000,
    payments: [
      {
        id: 'p2',
        date: '2024-01-18',
        amount: 20000,
        method: 'Bank Transfer',
        reference: 'BT789456',
      },
    ],
  },
];

const mockAttendance: AttendanceRecord[] = [];

const mockAnnouncements: Announcement[] = [
  {
    id: '1',
    title: 'Mid-Term Break Notice',
    content: 'School will close on 20th March for mid-term break. Resumption date is 27th March 2026.',
    date: '2026-01-10T09:00:00',
    priority: 'high',
    targetRoles: ['administrator', 'teacher', 'parent'],
    author: 'Principal',
  },
  {
    id: '2',
    title: 'Fee Payment Reminder',
    content: 'All Term 1 fees should be cleared by 25th January 2026. Please ensure timely payment.',
    date: '2026-01-12T14:00:00',
    priority: 'medium',
    targetRoles: ['parent', 'bursar'],
    author: 'Bursar',
  },
  {
    id: '3',
    title: 'Parent-Teacher Meeting',
    content: 'Annual Parent-Teacher meeting scheduled for 15th February 2026 at 2:00 PM.',
    date: '2026-01-14T10:00:00',
    priority: 'medium',
    targetRoles: ['parent', 'teacher', 'administrator'],
    author: 'Deputy Principal',
  },
];

const mockAcademicTerms: AcademicTerm[] = [
  {
    id: '1',
    name: 'Term 1',
    year: '2026',
    startDate: '2026-01-13',
    endDate: '2026-04-04',
    isCurrent: true,
  },
  {
    id: '2',
    name: 'Term 2',
    year: '2026',
    startDate: '2026-05-05',
    endDate: '2026-08-08',
    isCurrent: false,
  },
  {
    id: '3',
    name: 'Term 3',
    year: '2026',
    startDate: '2026-09-01',
    endDate: '2026-11-20',
    isCurrent: false,
  },
];

const mockExamSchedules: ExamSchedule[] = [
  {
    id: '1',
    subject: 'Mathematics',
    grade: 'Grade 3',
    date: '2026-03-20',
    time: '08:00 AM',
    duration: '1.5 hours',
  },
  {
    id: '2',
    subject: 'English',
    grade: 'Grade 3',
    date: '2026-03-21',
    time: '08:00 AM',
    duration: '1.5 hours',
  },
  {
    id: '3',
    subject: 'Science',
    grade: 'Grade 5',
    date: '2026-03-20',
    time: '10:00 AM',
    duration: '2 hours',
  },
];

const mockMessages: Message[] = [
  {
    id: '1',
    type: 'sms',
    recipient: '+254712345678',
    content: 'Dear parent, this is to remind you that Term 1 fees are due by 25th January.',
    sentDate: '2026-01-15T10:30:00',
    status: 'delivered',
    sentBy: 'Bursar',
  },
  {
    id: '2',
    type: 'email',
    recipient: 'pkamau@example.com',
    subject: 'Academic Progress Report',
    content: 'Dear Mr. Kamau, please find attached your child\'s academic progress report.',
    sentDate: '2026-01-14T15:00:00',
    status: 'sent',
    sentBy: 'Class Teacher',
  },
];

const mockAuditLogs: AuditLog[] = [
  {
    id: '1',
    user: 'Admin User',
    action: 'Created Student',
    record: 'John Kamau - TKA2024001',
    date: '2026-01-15',
    time: '09:30:00',
    details: 'New student registration',
  },
  {
    id: '2',
    user: 'Grace Njeri',
    action: 'Updated Attendance',
    record: 'Grade 3A - 15/01/2026',
    date: '2026-01-15',
    time: '08:15:00',
    details: 'Marked daily attendance',
  },
  {
    id: '3',
    user: 'Bursar',
    action: 'Recorded Payment',
    record: 'Mary Wanjiru - KSh 20,000',
    date: '2026-01-14',
    time: '11:45:00',
    details: 'M-Pesa payment received',
  },
];

export function AppProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<{ role: UserRole; name: string; lastLogin?: string } | null>(null);
  const [currentView, setCurrentView] = useState('login');
  const [students, setStudents] = useState<Student[]>(mockStudents);
  const [teachers, setTeachers] = useState<Teacher[]>(mockTeachers);
  const [assets, setAssets] = useState<Asset[]>(mockAssets);
  const [feeRecords, setFeeRecords] = useState<FeeRecord[]>(mockFeeRecords);
  const [attendanceRecords, setAttendanceRecords] = useState<AttendanceRecord[]>(mockAttendance);
  const [announcements, setAnnouncements] = useState<Announcement[]>(mockAnnouncements);
  const [academicTerms, setAcademicTerms] = useState<AcademicTerm[]>(mockAcademicTerms);
  const [examSchedules, setExamSchedules] = useState<ExamSchedule[]>(mockExamSchedules);
  const [messages, setMessages] = useState<Message[]>(mockMessages);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(mockAuditLogs);
  const [examResults, setExamResults] = useState<ExamResult[]>([]);

  const addStudent = (student: Student) => {
    setStudents([...students, student]);
    addAuditLog({
      id: Date.now().toString(),
      user: currentUser?.name || 'System',
      action: 'Created Student',
      record: `${student.firstName} ${student.lastName} - ${student.admissionNumber}`,
      date: new Date().toISOString().split('T')[0],
      time: new Date().toTimeString().split(' ')[0],
      details: 'New student registration',
    });
  };

  const updateStudent = (id: string, updatedData: Partial<Student>) => {
    setStudents(students.map(s => s.id === id ? { ...s, ...updatedData } : s));
    const student = students.find(s => s.id === id);
    if (student) {
      addAuditLog({
        id: Date.now().toString(),
        user: currentUser?.name || 'System',
        action: 'Updated Student',
        record: `${student.firstName} ${student.lastName} - ${student.admissionNumber}`,
        date: new Date().toISOString().split('T')[0],
        time: new Date().toTimeString().split(' ')[0],
        details: 'Student information updated',
      });
    }
  };

  const deleteStudent = (id: string) => {
    const student = students.find(s => s.id === id);
    setStudents(students.filter(s => s.id !== id));
    if (student) {
      addAuditLog({
        id: Date.now().toString(),
        user: currentUser?.name || 'System',
        action: 'Deleted Student',
        record: `${student.firstName} ${student.lastName} - ${student.admissionNumber}`,
        date: new Date().toISOString().split('T')[0],
        time: new Date().toTimeString().split(' ')[0],
        details: 'Student permanently deleted',
      });
    }
  };

  const archiveStudent = (id: string, reason?: string) => {
    setStudents(students.map(s => s.id === id ? {
      ...s,
      archived: true,
      archivedDate: new Date().toISOString(),
      archivedBy: currentUser?.name,
      transferReason: reason,
    } : s));
    const student = students.find(s => s.id === id);
    if (student) {
      addAuditLog({
        id: Date.now().toString(),
        user: currentUser?.name || 'System',
        action: 'Archived Student',
        record: `${student.firstName} ${student.lastName} - ${student.admissionNumber}`,
        date: new Date().toISOString().split('T')[0],
        time: new Date().toTimeString().split(' ')[0],
        details: reason || 'Student archived',
      });
    }
  };

  const restoreStudent = (id: string) => {
    setStudents(students.map(s => s.id === id ? {
      ...s,
      archived: false,
      archivedDate: undefined,
      archivedBy: undefined,
    } : s));
    const student = students.find(s => s.id === id);
    if (student) {
      addAuditLog({
        id: Date.now().toString(),
        user: currentUser?.name || 'System',
        action: 'Restored Student',
        record: `${student.firstName} ${student.lastName} - ${student.admissionNumber}`,
        date: new Date().toISOString().split('T')[0],
        time: new Date().toTimeString().split(' ')[0],
        details: 'Student restored from archive',
      });
    }
  };

  const addAsset = (asset: Asset) => {
    setAssets([...assets, asset]);
  };

  const updateAsset = (id: string, updatedData: Partial<Asset>) => {
    setAssets(assets.map(a => a.id === id ? { ...a, ...updatedData } : a));
  };

  const addAttendanceRecord = (record: AttendanceRecord) => {
    setAttendanceRecords([...attendanceRecords, record]);
  };

  const sendMessage = (message: Message) => {
    setMessages([...messages, message]);
    addAuditLog({
      id: Date.now().toString(),
      user: currentUser?.name || 'System',
      action: `Sent ${message.type.toUpperCase()}`,
      record: message.recipient,
      date: new Date().toISOString().split('T')[0],
      time: new Date().toTimeString().split(' ')[0],
      details: message.subject || message.content.substring(0, 50),
    });
  };

  const addAuditLog = (log: AuditLog) => {
    setAuditLogs([log, ...auditLogs]);
  };

  const addExamResult = (result: ExamResult) => {
    setExamResults([...examResults, result]);
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        currentView,
        setCurrentView,
        students,
        addStudent,
        updateStudent,
        deleteStudent,
        archiveStudent,
        restoreStudent,
        teachers,
        assets,
        addAsset,
        updateAsset,
        feeRecords,
        attendanceRecords,
        addAttendanceRecord,
        announcements,
        academicTerms,
        examSchedules,
        messages,
        sendMessage,
        auditLogs,
        addAuditLog,
        examResults,
        addExamResult,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}