/**
 * Three Kings Academy - School Management System
 * 
 * A comprehensive, CBC-aligned school management portal for Kenyan schools
 * serving Daycare through Grade 6.
 * 
 * Features:
 * - Multi-role authentication (Admin, Teacher, Parent, Bursar, Inventory Manager)
 * - Student management with admission, transfer, and archival capabilities
 * - CBC-aligned assessment and reporting system
 * - Fee management with M-Pesa integration support
 * - Inventory and asset tracking
 * - Attendance monitoring
 * - Parent portal with real-time updates
 * - Responsive design for desktop, tablet, and mobile
 * 
 * Color Scheme:
 * - Primary: Dark Blue (#0B1C2D)
 * - Accent: Gold (#d4af37)
 * - Background: White
 * 
 * Technology Stack:
 * - React with TypeScript
 * - Tailwind CSS v4
 * - Recharts for data visualization
 * - Radix UI components
 * - Context API for state management
 */

import { AppProvider, useApp } from '@/app/context/AppContext';
import { LoginScreen } from '@/app/components/LoginScreen';
import { DashboardLayout } from '@/app/components/DashboardLayout';
import { AdminDashboard } from '@/app/components/AdminDashboard';
import { TeacherDashboard } from '@/app/components/TeacherDashboard';
import { StudentManagement } from '@/app/components/StudentManagement';
import { AdmissionModule } from '@/app/components/AdmissionModule';
import { FeesAccounts } from '@/app/components/FeesAccounts';
import { InventoryModule } from '@/app/components/InventoryModule';
import { ParentPortal } from '@/app/components/ParentPortal';
import { ExamsReports, AttendanceModule, StaffRecords, SettingsView } from '@/app/components/PlaceholderViews';
import { Toaster } from '@/app/components/ui/sonner';

function AppContent() {
  const { currentUser, currentView } = useApp();

  // If not logged in, show login screen
  if (!currentUser) {
    return <LoginScreen />;
  }

  // Render the appropriate view based on currentView
  const renderView = () => {
    // Role-specific dashboards
    if (currentView === 'dashboard') {
      if (currentUser.role === 'parent') {
        return <ParentPortal />;
      } else if (currentUser.role === 'teacher') {
        return <TeacherDashboard />;
      } else {
        return <AdminDashboard />;
      }
    }

    switch (currentView) {
      case 'students':
        return <StudentManagement />;
      case 'admissions':
        return <AdmissionModule />;
      case 'exams':
        return <ExamsReports />;
      case 'attendance':
        return <AttendanceModule />;
      case 'fees':
        return <FeesAccounts />;
      case 'inventory':
        return <InventoryModule />;
      case 'staff':
        return <StaffRecords />;
      case 'settings':
        return <SettingsView />;
      default:
        return <AdminDashboard />;
    }
  };

  return (
    <DashboardLayout>
      {renderView()}
    </DashboardLayout>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
      <Toaster />
    </AppProvider>
  );
}