import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Textarea } from '@/app/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/app/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/app/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/app/components/ui/table';
import { Badge } from '@/app/components/ui/badge';
import { Switch } from '@/app/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/app/components/ui/dialog';
import {
  Settings,
  Building2,
  Upload,
  Calendar,
  BookOpen,
  Award,
  Users,
  Download,
  Save,
  RotateCcw,
  Lock,
  Eye,
  EyeOff,
  Plus,
  Trash2,
  Edit,
} from 'lucide-react';
import { toast } from 'sonner';

export function SystemSettings() {
  const [showPassword, setShowPassword] = useState(false);
  const [schoolInfo, setSchoolInfo] = useState({
    name: 'Three Kings Academy',
    motto: 'Excellence in Foundation Education',
    address: 'P.O. Box 12345, Nairobi, Kenya',
    phone: '+254 712 345 678',
    email: 'info@threekings.ac.ke',
    website: 'www.threekings.ac.ke',
  });

  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleSaveSchoolInfo = () => {
    toast.success('School information updated successfully');
  };

  const handleChangePassword = () => {
    if (!currentPassword || !newPassword || !confirmPassword) {
      toast.error('Please fill in all password fields');
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error('New passwords do not match');
      return;
    }
    if (newPassword.length < 8) {
      toast.error('Password must be at least 8 characters long');
      return;
    }
    toast.success('Password changed successfully');
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
  };

  const handleBackupData = () => {
    toast.success('Data backup initiated successfully');
  };

  const handleRestoreBackup = () => {
    toast.success('Backup restoration initiated');
  };

  const cbcLearningAreas = [
    'Mathematics',
    'English',
    'Kiswahili',
    'Science and Technology',
    'Social Studies',
    'Creative Arts',
    'Physical Education',
    'Religious Education',
  ];

  const users = [
    {
      id: '1',
      name: 'Admin User',
      email: 'admin@threekings.ac.ke',
      role: 'Administrator',
      status: 'Active',
      lastLogin: '2026-01-15 09:30',
    },
    {
      id: '2',
      name: 'Grace Njeri',
      email: 'gnjeri@threekings.ac.ke',
      role: 'Teacher',
      status: 'Active',
      lastLogin: '2026-01-15 08:15',
    },
    {
      id: '3',
      name: 'Accounts Officer',
      email: 'accounts@threekings.ac.ke',
      role: 'Bursar',
      status: 'Active',
      lastLogin: '2026-01-14 11:45',
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl">System Settings</h1>
          <p className="text-muted-foreground mt-1">
            Configure school information and system preferences
          </p>
        </div>
      </div>

      <Tabs defaultValue="school" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 lg:grid-cols-7">
          <TabsTrigger value="school" className="gap-1">
            <Building2 className="w-4 h-4" />
            School
          </TabsTrigger>
          <TabsTrigger value="academic" className="gap-1">
            <Calendar className="w-4 h-4" />
            Academic
          </TabsTrigger>
          <TabsTrigger value="cbc" className="gap-1">
            <BookOpen className="w-4 h-4" />
            CBC
          </TabsTrigger>
          <TabsTrigger value="grading" className="gap-1">
            <Award className="w-4 h-4" />
            Grading
          </TabsTrigger>
          <TabsTrigger value="users" className="gap-1">
            <Users className="w-4 h-4" />
            Users
          </TabsTrigger>
          <TabsTrigger value="security" className="gap-1">
            <Lock className="w-4 h-4" />
            Security
          </TabsTrigger>
          <TabsTrigger value="backup" className="gap-1">
            <Download className="w-4 h-4" />
            Backup
          </TabsTrigger>
        </TabsList>

        {/* School Information */}
        <TabsContent value="school" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>School Information</CardTitle>
              <CardDescription>
                Basic information about your institution
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* School Logo */}
              <div className="space-y-2">
                <Label>School Logo</Label>
                <div className="flex items-center gap-4">
                  <div className="w-24 h-24 rounded-lg bg-secondary border-2 border-dashed flex items-center justify-center">
                    <Building2 className="w-12 h-12 text-muted-foreground" />
                  </div>
                  <div className="flex-1">
                    <Button variant="outline" className="gap-2">
                      <Upload className="w-4 h-4" />
                      Upload Logo
                    </Button>
                    <p className="text-xs text-muted-foreground mt-2">
                      Recommended size: 200x200px. Max file size: 2MB
                    </p>
                  </div>
                </div>
              </div>

              {/* School Details */}
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>School Name</Label>
                  <Input
                    value={schoolInfo.name}
                    onChange={(e) =>
                      setSchoolInfo({ ...schoolInfo, name: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>School Motto</Label>
                  <Input
                    value={schoolInfo.motto}
                    onChange={(e) =>
                      setSchoolInfo({ ...schoolInfo, motto: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label>Address</Label>
                  <Textarea
                    value={schoolInfo.address}
                    onChange={(e) =>
                      setSchoolInfo({ ...schoolInfo, address: e.target.value })
                    }
                    rows={2}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Phone Number</Label>
                  <Input
                    value={schoolInfo.phone}
                    onChange={(e) =>
                      setSchoolInfo({ ...schoolInfo, phone: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Email Address</Label>
                  <Input
                    type="email"
                    value={schoolInfo.email}
                    onChange={(e) =>
                      setSchoolInfo({ ...schoolInfo, email: e.target.value })
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>Website</Label>
                  <Input
                    value={schoolInfo.website}
                    onChange={(e) =>
                      setSchoolInfo({ ...schoolInfo, website: e.target.value })
                    }
                  />
                </div>
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline">
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Reset
                </Button>
                <Button onClick={handleSaveSchoolInfo} className="gap-2">
                  <Save className="w-4 h-4" />
                  Save Changes
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Academic Settings */}
        <TabsContent value="academic" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Academic Year Settings</CardTitle>
              <CardDescription>
                Configure terms, calendars, and academic periods
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>Current Academic Year</Label>
                  <Select defaultValue="2026">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="2024">2024</SelectItem>
                      <SelectItem value="2025">2025</SelectItem>
                      <SelectItem value="2026">2026</SelectItem>
                      <SelectItem value="2027">2027</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Current Term</Label>
                  <Select defaultValue="term1">
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="term1">Term 1</SelectItem>
                      <SelectItem value="term2">Term 2</SelectItem>
                      <SelectItem value="term3">Term 3</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label>Academic Terms</Label>
                  <Button variant="outline" size="sm" className="gap-1">
                    <Plus className="w-3 h-3" />
                    Add Term
                  </Button>
                </div>
                <div className="border rounded-lg">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Term</TableHead>
                        <TableHead>Start Date</TableHead>
                        <TableHead>End Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      <TableRow>
                        <TableCell className="font-medium">Term 1 2026</TableCell>
                        <TableCell>Jan 13, 2026</TableCell>
                        <TableCell>Apr 04, 2026</TableCell>
                        <TableCell>
                          <Badge className="bg-green-500">Current</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="ghost" size="sm">
                              <Edit className="w-3 h-3" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Term 2 2026</TableCell>
                        <TableCell>May 05, 2026</TableCell>
                        <TableCell>Aug 08, 2026</TableCell>
                        <TableCell>
                          <Badge variant="outline">Upcoming</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="ghost" size="sm">
                              <Edit className="w-3 h-3" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                      <TableRow>
                        <TableCell className="font-medium">Term 3 2026</TableCell>
                        <TableCell>Sep 01, 2026</TableCell>
                        <TableCell>Nov 20, 2026</TableCell>
                        <TableCell>
                          <Badge variant="outline">Upcoming</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="ghost" size="sm">
                              <Edit className="w-3 h-3" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>
              </div>

              <div className="flex justify-end">
                <Button className="gap-2">
                  <Save className="w-4 h-4" />
                  Save Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* CBC Learning Areas */}
        <TabsContent value="cbc" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>CBC Learning Areas</CardTitle>
              <CardDescription>
                Manage Competency-Based Curriculum learning areas
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <p className="text-sm text-muted-foreground">
                  Configure the learning areas assessed in your school
                </p>
                <Button variant="outline" size="sm" className="gap-1">
                  <Plus className="w-3 h-3" />
                  Add Learning Area
                </Button>
              </div>

              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Learning Area</TableHead>
                      <TableHead>Code</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {cbcLearningAreas.map((area, index) => (
                      <TableRow key={index}>
                        <TableCell className="font-medium">{area}</TableCell>
                        <TableCell className="font-mono text-sm">
                          LA{String(index + 1).padStart(2, '0')}
                        </TableCell>
                        <TableCell>
                          <Badge className="bg-green-500">Active</Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="ghost" size="sm">
                              <Edit className="w-3 h-3" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Trash2 className="w-3 h-3 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Grading Scale */}
        <TabsContent value="grading" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>CBC Grading Scale</CardTitle>
              <CardDescription>
                Configure competency-based grading criteria
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Grade</TableHead>
                      <TableHead>Min Score</TableHead>
                      <TableHead>Max Score</TableHead>
                      <TableHead>Description</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    <TableRow>
                      <TableCell>
                        <Badge className="bg-green-500">Exceeds Expectations</Badge>
                      </TableCell>
                      <TableCell>80</TableCell>
                      <TableCell>100</TableCell>
                      <TableCell>Outstanding performance</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">
                          <Edit className="w-3 h-3" />
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>
                        <Badge className="bg-blue-500">Meets Expectations</Badge>
                      </TableCell>
                      <TableCell>60</TableCell>
                      <TableCell>79</TableCell>
                      <TableCell>Good performance</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">
                          <Edit className="w-3 h-3" />
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>
                        <Badge className="bg-yellow-500">Approaches Expectations</Badge>
                      </TableCell>
                      <TableCell>40</TableCell>
                      <TableCell>59</TableCell>
                      <TableCell>Satisfactory performance</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">
                          <Edit className="w-3 h-3" />
                        </Button>
                      </TableCell>
                    </TableRow>
                    <TableRow>
                      <TableCell>
                        <Badge variant="destructive">Below Expectations</Badge>
                      </TableCell>
                      <TableCell>0</TableCell>
                      <TableCell>39</TableCell>
                      <TableCell>Needs improvement</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">
                          <Edit className="w-3 h-3" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  </TableBody>
                </Table>
              </div>

              <div className="p-4 bg-secondary/30 rounded-lg">
                <h4 className="font-semibold mb-2">Report Card Template</h4>
                <p className="text-sm text-muted-foreground mb-3">
                  Customize the layout and content of student report cards
                </p>
                <Button variant="outline" className="gap-2">
                  <Edit className="w-4 h-4" />
                  Edit Report Template
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* User Management */}
        <TabsContent value="users" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>User Management</CardTitle>
              <CardDescription>
                Manage system users and their access permissions
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-end">
                <Button className="gap-2">
                  <Plus className="w-4 h-4" />
                  Add New User
                </Button>
              </div>

              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Email</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Last Login</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.name}</TableCell>
                        <TableCell className="text-sm">{user.email}</TableCell>
                        <TableCell>
                          <Badge variant="outline">{user.role}</Badge>
                        </TableCell>
                        <TableCell>
                          <Badge className="bg-green-500">{user.status}</Badge>
                        </TableCell>
                        <TableCell className="text-sm font-mono">
                          {user.lastLogin}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button variant="ghost" size="sm">
                              <Edit className="w-3 h-3" />
                            </Button>
                            <Button variant="ghost" size="sm">
                              <Trash2 className="w-3 h-3 text-destructive" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Settings */}
        <TabsContent value="security" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
              <CardDescription>
                Manage password and security preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Change Password */}
              <div className="space-y-4">
                <h3 className="font-semibold">Change Password</h3>
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2 md:col-span-2">
                    <Label>Current Password</Label>
                    <div className="relative">
                      <Input
                        type={showPassword ? 'text' : 'password'}
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                      />
                      <Button
                        type="button"
                        variant="ghost"
                        size="icon"
                        className="absolute right-0 top-0"
                        onClick={() => setShowPassword(!showPassword)}
                      >
                        {showPassword ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label>New Password</Label>
                    <Input
                      type="password"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Confirm New Password</Label>
                    <Input
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                    />
                  </div>
                </div>
                <Button onClick={handleChangePassword} className="gap-2">
                  <Lock className="w-4 h-4" />
                  Change Password
                </Button>
              </div>

              {/* Security Options */}
              <div className="space-y-4 pt-6 border-t">
                <h3 className="font-semibold">Security Options</h3>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Two-Factor Authentication</Label>
                      <p className="text-sm text-muted-foreground">
                        Add an extra layer of security to your account
                      </p>
                    </div>
                    <Switch />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Session Timeout</Label>
                      <p className="text-sm text-muted-foreground">
                        Auto-logout after 30 minutes of inactivity
                      </p>
                    </div>
                    <Switch defaultChecked />
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <Label>Login Notifications</Label>
                      <p className="text-sm text-muted-foreground">
                        Receive email alerts for new logins
                      </p>
                    </div>
                    <Switch />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Backup & Restore */}
        <TabsContent value="backup" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Backup & Restore</CardTitle>
              <CardDescription>
                Manage data backups and system restoration
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <Card>
                  <CardHeader className="pb-3">
                    <CardDescription>Last Backup</CardDescription>
                    <CardTitle className="text-2xl">3 days ago</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Button onClick={handleBackupData} className="w-full gap-2">
                      <Download className="w-4 h-4" />
                      Backup Now
                    </Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardDescription>Backup Size</CardDescription>
                    <CardTitle className="text-2xl">245 MB</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <Button
                      onClick={handleRestoreBackup}
                      variant="outline"
                      className="w-full gap-2"
                    >
                      <RotateCcw className="w-4 h-4" />
                      Restore Backup
                    </Button>
                  </CardContent>
                </Card>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold">Automatic Backup</h3>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div>
                    <Label>Enable Automatic Daily Backup</Label>
                    <p className="text-sm text-muted-foreground">
                      Backup data automatically at 2:00 AM daily
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </div>

              <div className="space-y-2">
                <h3 className="font-semibold">Export Data</h3>
                <div className="grid gap-2 md:grid-cols-2">
                  <Button variant="outline" className="gap-2">
                    <Download className="w-4 h-4" />
                    Export to Excel
                  </Button>
                  <Button variant="outline" className="gap-2">
                    <Download className="w-4 h-4" />
                    Export to PDF
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
