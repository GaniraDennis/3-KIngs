import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Badge } from '@/app/components/ui/badge';
import { Alert, AlertDescription } from '@/app/components/ui/alert';
import { ScrollArea } from '@/app/components/ui/scroll-area';
import { useApp } from '@/app/context/AppContext';
import {
  Bell,
  Calendar,
  AlertTriangle,
  FileText,
  Wallet,
  Clock,
  Info,
} from 'lucide-react';
import { format } from 'date-fns';

export function EmergencyAlerts() {
  const { announcements, currentUser } = useApp();

  const emergencyAnnouncements = announcements.filter(
    (a) => a.priority === 'emergency' && a.targetRoles.includes(currentUser?.role || 'parent')
  );

  if (emergencyAnnouncements.length === 0) return null;

  return (
    <div className="space-y-2">
      {emergencyAnnouncements.map((announcement) => (
        <Alert
          key={announcement.id}
          variant="destructive"
          className="border-2 animate-pulse"
        >
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>{announcement.title}</strong> - {announcement.content}
          </AlertDescription>
        </Alert>
      ))}
    </div>
  );
}

export function AnnouncementsWidget() {
  const { announcements, currentUser } = useApp();

  const userAnnouncements = announcements
    .filter(
      (a) =>
        a.priority !== 'emergency' &&
        a.targetRoles.includes(currentUser?.role || 'parent')
    )
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high':
        return 'bg-red-500';
      case 'medium':
        return 'bg-yellow-500';
      case 'low':
        return 'bg-blue-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Bell className="w-5 h-5 text-primary" />
          <CardTitle className="text-lg">School Announcements</CardTitle>
        </div>
        <CardDescription>Latest updates and notices</CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[300px]">
          <div className="space-y-3">
            {userAnnouncements.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <Bell className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No announcements</p>
              </div>
            ) : (
              userAnnouncements.map((announcement) => (
                <div
                  key={announcement.id}
                  className="p-3 border rounded-lg hover:bg-secondary/50 transition-colors"
                >
                  <div className="flex items-start gap-2">
                    <div
                      className={`w-2 h-2 rounded-full mt-2 ${getPriorityColor(
                        announcement.priority
                      )}`}
                    />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <h4 className="font-semibold text-sm">
                          {announcement.title}
                        </h4>
                        <Badge variant="outline" className="text-xs">
                          {announcement.priority}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">
                        {announcement.content}
                      </p>
                      <div className="flex items-center gap-3 text-xs text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {format(new Date(announcement.date), 'MMM dd, yyyy')}
                        </span>
                        <span>By {announcement.author}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

export function AcademicCalendarWidget() {
  const { academicTerms } = useApp();

  const currentTerm = academicTerms.find((term) => term.isCurrent);

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-primary" />
          <CardTitle className="text-lg">Academic Calendar</CardTitle>
        </div>
        <CardDescription>Current term and schedule</CardDescription>
      </CardHeader>
      <CardContent>
        {currentTerm && (
          <div className="mb-4 p-4 bg-primary/10 border border-primary/20 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-semibold text-primary">
                {currentTerm.name} {currentTerm.year}
              </h4>
              <Badge className="bg-primary">Current</Badge>
            </div>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <span className="text-muted-foreground">Start:</span>{' '}
                <span className="font-medium">
                  {format(new Date(currentTerm.startDate), 'MMM dd, yyyy')}
                </span>
              </div>
              <div>
                <span className="text-muted-foreground">End:</span>{' '}
                <span className="font-medium">
                  {format(new Date(currentTerm.endDate), 'MMM dd, yyyy')}
                </span>
              </div>
            </div>
          </div>
        )}

        <div className="space-y-2">
          <h4 className="font-semibold text-sm mb-2">All Terms</h4>
          {academicTerms.map((term) => (
            <div
              key={term.id}
              className={`p-3 border rounded-lg ${
                term.isCurrent ? 'border-primary bg-primary/5' : ''
              }`}
            >
              <div className="flex items-center justify-between">
                <div>
                  <h5 className="font-medium text-sm">
                    {term.name} {term.year}
                  </h5>
                  <p className="text-xs text-muted-foreground">
                    {format(new Date(term.startDate), 'MMM dd')} -{' '}
                    {format(new Date(term.endDate), 'MMM dd, yyyy')}
                  </p>
                </div>
                {term.isCurrent && (
                  <Badge variant="default" className="text-xs">
                    Active
                  </Badge>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

export function ExamTimetableWidget() {
  const { examSchedules } = useApp();

  const upcomingExams = examSchedules
    .filter((exam) => new Date(exam.date) >= new Date())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
    .slice(0, 5);

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <FileText className="w-5 h-5 text-primary" />
          <CardTitle className="text-lg">Exam Timetable</CardTitle>
        </div>
        <CardDescription>Upcoming examinations</CardDescription>
      </CardHeader>
      <CardContent>
        {upcomingExams.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>No upcoming exams</p>
          </div>
        ) : (
          <div className="space-y-3">
            {upcomingExams.map((exam) => (
              <div
                key={exam.id}
                className="p-3 border rounded-lg hover:bg-secondary/50 transition-colors"
              >
                <div className="flex items-center justify-between mb-1">
                  <h4 className="font-semibold text-sm">{exam.subject}</h4>
                  <Badge variant="outline">{exam.grade}</Badge>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {format(new Date(exam.date), 'MMM dd, yyyy')}
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {exam.time}
                  </div>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Duration: {exam.duration}
                </p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function FeeRemindersWidget() {
  const { feeRecords, students, currentUser } = useApp();

  const pendingFees = feeRecords
    .filter((record) => record.balance > 0)
    .map((record) => {
      const student = students.find((s) => s.id === record.studentId);
      return { ...record, student };
    })
    .slice(0, 5);

  // For parents, show only their child's fees
  const displayFees =
    currentUser?.role === 'parent'
      ? pendingFees.filter(
          (f) => f.student?.parentName === currentUser.name
        )
      : pendingFees;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Wallet className="w-5 h-5 text-primary" />
          <CardTitle className="text-lg">Fee Reminders</CardTitle>
        </div>
        <CardDescription>Pending fee payments</CardDescription>
      </CardHeader>
      <CardContent>
        {displayFees.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Wallet className="w-12 h-12 mx-auto mb-2 opacity-50" />
            <p>All fees cleared!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {displayFees.map((record) => (
              <div
                key={record.id}
                className="p-3 border border-yellow-200 bg-yellow-50/50 rounded-lg"
              >
                <div className="flex items-center justify-between mb-1">
                  <h4 className="font-semibold text-sm">
                    {record.student?.firstName} {record.student?.lastName}
                  </h4>
                  <Badge variant="destructive">Pending</Badge>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <span className="text-muted-foreground">Total:</span>{' '}
                    <span className="font-medium">
                      KSh {record.totalFees.toLocaleString()}
                    </span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Paid:</span>{' '}
                    <span className="font-medium">
                      KSh {record.paidAmount.toLocaleString()}
                    </span>
                  </div>
                </div>
                <div className="mt-2 pt-2 border-t border-yellow-200">
                  <span className="text-xs text-muted-foreground">
                    Balance:{' '}
                  </span>
                  <span className="text-sm font-bold text-red-600">
                    KSh {record.balance.toLocaleString()}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function SystemNotificationsWidget() {
  const notifications = [
    {
      id: '1',
      title: 'System Update Completed',
      message: 'The system has been successfully updated to version 2.0',
      time: '2 hours ago',
      type: 'success',
    },
    {
      id: '2',
      title: 'Backup Reminder',
      message: 'Last backup was 3 days ago. Consider backing up your data.',
      time: '5 hours ago',
      type: 'warning',
    },
    {
      id: '3',
      title: 'New Feature Available',
      message: 'CBC Report Cards generator is now available in Exams module.',
      time: '1 day ago',
      type: 'info',
    },
  ];

  const getIcon = (type: string) => {
    switch (type) {
      case 'warning':
        return <AlertTriangle className="w-4 h-4 text-yellow-600" />;
      case 'success':
        return <Info className="w-4 h-4 text-green-600" />;
      default:
        return <Info className="w-4 h-4 text-blue-600" />;
    }
  };

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center gap-2">
          <Bell className="w-5 h-5 text-primary" />
          <CardTitle className="text-lg">System Notifications</CardTitle>
        </div>
        <CardDescription>Recent system updates</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {notifications.map((notification) => (
            <div
              key={notification.id}
              className="p-3 border rounded-lg hover:bg-secondary/50 transition-colors"
            >
              <div className="flex items-start gap-2">
                {getIcon(notification.type)}
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-sm">
                    {notification.title}
                  </h4>
                  <p className="text-xs text-muted-foreground mt-1">
                    {notification.message}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {notification.time}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
