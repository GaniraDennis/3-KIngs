import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Users, GraduationCap, Wallet, Package, UserPlus, FileText, TrendingUp } from 'lucide-react';
import { useApp } from '@/app/context/AppContext';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const enrollmentData = [
  { month: 'Jan', students: 120 },
  { month: 'Feb', students: 125 },
  { month: 'Mar', students: 130 },
  { month: 'Apr', students: 135 },
  { month: 'May', students: 142 },
  { month: 'Jun', students: 145 },
];

const attendanceData = [
  { day: 'Mon', present: 138, absent: 7 },
  { day: 'Tue', present: 142, absent: 3 },
  { day: 'Wed', present: 140, absent: 5 },
  { day: 'Thu', present: 144, absent: 1 },
  { day: 'Fri', present: 141, absent: 4 },
];

const gradeDistribution = [
  { name: 'Daycare', value: 20, color: '#0B1C2D' },
  { name: 'PP1', value: 18, color: '#60a5fa' },
  { name: 'PP2', value: 22, color: '#d4af37' },
  { name: 'Grade 1-3', value: 45, color: '#34d399' },
  { name: 'Grade 4-6', value: 40, color: '#f87171' },
];

export function AdminDashboard() {
  const { students, teachers, assets, feeRecords, setCurrentView } = useApp();

  const totalFeesBalance = feeRecords.reduce((sum, record) => sum + record.balance, 0);
  const totalAssetValue = assets.reduce((sum, asset) => sum + asset.currentValue, 0);

  const stats = [
    {
      title: 'Total Students',
      value: students.length.toString(),
      icon: <Users className="w-6 h-6" />,
      description: '+12 this month',
      trend: 'up',
      color: 'bg-blue-500',
    },
    {
      title: 'Teachers',
      value: teachers.length.toString(),
      icon: <GraduationCap className="w-6 h-6" />,
      description: 'All active',
      trend: 'neutral',
      color: 'bg-green-500',
    },
    {
      title: 'Fees Balance',
      value: `KSh ${totalFeesBalance.toLocaleString()}`,
      icon: <Wallet className="w-6 h-6" />,
      description: '15 pending payments',
      trend: 'down',
      color: 'bg-yellow-500',
    },
    {
      title: 'Asset Value',
      value: `KSh ${totalAssetValue.toLocaleString()}`,
      icon: <Package className="w-6 h-6" />,
      description: `${assets.length} items`,
      trend: 'up',
      color: 'bg-purple-500',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl">Dashboard</h1>
          <p className="text-muted-foreground mt-1">Welcome back! Here's what's happening today.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button onClick={() => setCurrentView('admissions')} className="gap-2">
            <UserPlus className="w-4 h-4" />
            Register Student
          </Button>
          <Button variant="outline" onClick={() => setCurrentView('exams')} className="gap-2">
            <FileText className="w-4 h-4" />
            Generate Report
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm text-muted-foreground">{stat.title}</CardTitle>
              <div className={`${stat.color} p-2 rounded-lg text-white`}>
                {stat.icon}
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl mb-1">{stat.value}</div>
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                {stat.trend === 'up' && <TrendingUp className="w-3 h-3 text-green-500" />}
                {stat.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Enrollment Growth */}
        <Card>
          <CardHeader>
            <CardTitle>Enrollment Growth</CardTitle>
            <CardDescription>Student enrollment over the last 6 months</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={enrollmentData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="students" stroke="#0B1C2D" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Attendance Trends */}
        <Card>
          <CardHeader>
            <CardTitle>Attendance Trends</CardTitle>
            <CardDescription>This week's attendance overview</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={attendanceData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="present" fill="#34d399" />
                <Bar dataKey="absent" fill="#f87171" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Grade Distribution and Recent Activities */}
      <div className="grid gap-6 md:grid-cols-2">
        {/* Grade Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Students by Grade</CardTitle>
            <CardDescription>Current distribution across CBC levels</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={gradeDistribution}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {gradeDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Recent Activities */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Activities</CardTitle>
            <CardDescription>Latest system activities</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 mt-2 rounded-full bg-green-500"></div>
                <div className="flex-1">
                  <p className="text-sm">New student registered</p>
                  <p className="text-xs text-muted-foreground">John Kamau admitted to Grade 3A</p>
                  <p className="text-xs text-muted-foreground">2 hours ago</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 mt-2 rounded-full bg-blue-500"></div>
                <div className="flex-1">
                  <p className="text-sm">Fee payment received</p>
                  <p className="text-xs text-muted-foreground">KSh 35,000 from Mary Wanjiru</p>
                  <p className="text-xs text-muted-foreground">5 hours ago</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 mt-2 rounded-full bg-yellow-500"></div>
                <div className="flex-1">
                  <p className="text-sm">Report cards generated</p>
                  <p className="text-xs text-muted-foreground">Term 1 reports for Grade 5B</p>
                  <p className="text-xs text-muted-foreground">1 day ago</p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <div className="w-2 h-2 mt-2 rounded-full bg-purple-500"></div>
                <div className="flex-1">
                  <p className="text-sm">New asset added</p>
                  <p className="text-xs text-muted-foreground">Smart Board for Grade 5 classroom</p>
                  <p className="text-xs text-muted-foreground">2 days ago</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
