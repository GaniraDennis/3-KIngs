import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Progress } from '@/app/components/ui/progress';
import { 
  Users, 
  ClipboardCheck, 
  FileText, 
  Calendar,
  CheckCircle,
  AlertCircle,
  TrendingUp
} from 'lucide-react';
import { useApp } from '@/app/context/AppContext';

export function TeacherDashboard() {
  const { students, setCurrentView } = useApp();

  // Mock data for teacher's classes
  const myClasses = [
    { grade: 'Grade 3', stream: 'A', students: 35 },
    { grade: 'Grade 5', stream: 'B', students: 32 },
  ];

  const myStudents = students.filter(s => 
    (s.grade === 'Grade 3' && s.stream === 'A') || 
    (s.grade === 'Grade 5' && s.stream === 'B')
  );

  const todayAttendance = {
    present: Math.floor(myStudents.length * 0.95),
    absent: Math.floor(myStudents.length * 0.05),
  };

  const upcomingTasks = [
    {
      id: '1',
      title: 'Submit Grade 3A Mathematics Assessment',
      dueDate: '2024-01-18',
      priority: 'high',
      completed: false,
    },
    {
      id: '2',
      title: 'Grade 5B Science Projects Review',
      dueDate: '2024-01-20',
      priority: 'medium',
      completed: false,
    },
    {
      id: '3',
      title: 'Parent-Teacher Meeting Preparation',
      dueDate: '2024-01-22',
      priority: 'medium',
      completed: false,
    },
    {
      id: '4',
      title: 'Term 1 Report Cards - Grade 3A',
      dueDate: '2024-01-25',
      priority: 'high',
      completed: false,
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl">Teacher Dashboard</h1>
        <p className="text-muted-foreground mt-1">Welcome back! Here's an overview of your classes.</p>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">My Classes</CardTitle>
            <Users className="w-5 h-5 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{myClasses.length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Active classes
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Total Students</CardTitle>
            <Users className="w-5 h-5 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{myStudents.length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Under your care
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Today's Attendance</CardTitle>
            <ClipboardCheck className="w-5 h-5 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{todayAttendance.present}/{myStudents.length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {todayAttendance.absent} absent
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Pending Tasks</CardTitle>
            <FileText className="w-5 h-5 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">{upcomingTasks.filter(t => !t.completed).length}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Tasks to complete
            </p>
          </CardContent>
        </Card>
      </div>

      {/* My Classes */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>My Classes</CardTitle>
              <CardDescription>Classes you're teaching this term</CardDescription>
            </div>
            <Button onClick={() => setCurrentView('students')}>
              View All Students
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-4">
            {myClasses.map((classItem, index) => (
              <Card key={index}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-medium">{classItem.grade} - {classItem.stream}</h3>
                      <p className="text-sm text-muted-foreground">{classItem.students} students</p>
                    </div>
                    <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-primary-foreground">
                      {classItem.students}
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Attendance Rate</span>
                      <span>95%</span>
                    </div>
                    <Progress value={95} className="h-2" />
                  </div>
                  <div className="flex gap-2 mt-4">
                    <Button variant="outline" size="sm" className="flex-1" onClick={() => setCurrentView('attendance')}>
                      Mark Attendance
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1" onClick={() => setCurrentView('exams')}>
                      Add Scores
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Upcoming Tasks */}
      <Card>
        <CardHeader>
          <CardTitle>Upcoming Tasks</CardTitle>
          <CardDescription>Important deadlines and activities</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {upcomingTasks.map((task) => (
              <div key={task.id} className="flex items-start gap-3 p-3 border rounded-lg">
                <div className="mt-1">
                  {task.completed ? (
                    <CheckCircle className="w-5 h-5 text-green-500" />
                  ) : (
                    <div className={`w-5 h-5 rounded-full border-2 ${
                      task.priority === 'high' ? 'border-red-500' : 'border-gray-300'
                    }`}></div>
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className={`text-sm font-medium ${task.completed ? 'line-through text-muted-foreground' : ''}`}>
                        {task.title}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        Due: {new Date(task.dueDate).toLocaleDateString('en-KE', {
                          month: 'short',
                          day: 'numeric',
                        })}
                      </p>
                    </div>
                    <Badge variant={task.priority === 'high' ? 'destructive' : 'secondary'}>
                      {task.priority}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Activities */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activities</CardTitle>
          <CardDescription>Your recent actions and updates</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 mt-2 rounded-full bg-green-500"></div>
              <div className="flex-1">
                <p className="text-sm">Attendance marked for Grade 3A</p>
                <p className="text-xs text-muted-foreground">35 students present, 0 absent</p>
                <p className="text-xs text-muted-foreground">2 hours ago</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 mt-2 rounded-full bg-blue-500"></div>
              <div className="flex-1">
                <p className="text-sm">Mathematics assessment scores uploaded</p>
                <p className="text-xs text-muted-foreground">Grade 5B - Topic: Fractions</p>
                <p className="text-xs text-muted-foreground">1 day ago</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 mt-2 rounded-full bg-yellow-500"></div>
              <div className="flex-1">
                <p className="text-sm">Parent communication sent</p>
                <p className="text-xs text-muted-foreground">Homework reminder for Grade 3A</p>
                <p className="text-xs text-muted-foreground">2 days ago</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
