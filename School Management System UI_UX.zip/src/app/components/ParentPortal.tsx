import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Avatar, AvatarFallback } from '@/app/components/ui/avatar';
import { Progress } from '@/app/components/ui/progress';
import { 
  User, 
  Calendar, 
  Wallet, 
  FileText, 
  Bell,
  Download,
  CheckCircle,
  XCircle,
  Clock
} from 'lucide-react';
import { useApp } from '@/app/context/AppContext';

export function ParentPortal() {
  const { students, feeRecords } = useApp();
  
  // For demo, we'll show the first student
  const myChild = students[0];
  const myFeeRecord = feeRecords.find(r => r.studentId === myChild?.id);

  if (!myChild) {
    return (
      <div className="flex items-center justify-center h-96">
        <p className="text-muted-foreground">No student information available</p>
      </div>
    );
  }

  const attendanceRate = 95; // Mock data

  const announcements = [
    {
      id: '1',
      title: 'Mid-Term Break Notice',
      message: 'School will close on Friday, March 15th for mid-term break. Resumption is on Monday, March 25th.',
      date: '2024-03-10',
      priority: 'high',
    },
    {
      id: '2',
      title: 'Parent-Teacher Meeting',
      message: 'Parents are invited to attend the quarterly parent-teacher meeting on Saturday, March 30th at 9:00 AM.',
      date: '2024-03-08',
      priority: 'medium',
    },
    {
      id: '3',
      title: 'Sports Day Registration',
      message: 'Register your child for the upcoming Sports Day event. Registration closes on March 20th.',
      date: '2024-03-05',
      priority: 'low',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl">Parent Portal</h1>
        <p className="text-muted-foreground mt-1">View your child's academic progress and school information</p>
      </div>

      {/* Child Profile Card */}
      <Card>
        <CardHeader>
          <CardTitle>My Child</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <Avatar className="h-20 w-20">
              <AvatarFallback className="bg-primary text-primary-foreground text-2xl">
                {myChild.firstName[0]}{myChild.lastName[0]}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h3 className="text-xl">{myChild.firstName} {myChild.lastName}</h3>
              <p className="text-sm text-muted-foreground">{myChild.admissionNumber}</p>
              <div className="flex gap-4 mt-2">
                <div className="flex items-center gap-2 text-sm">
                  <User className="w-4 h-4 text-muted-foreground" />
                  <span>{myChild.grade} {myChild.stream}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Badge className="bg-green-500">Active</Badge>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Attendance Rate</CardTitle>
            <Calendar className="w-5 h-5 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl mb-2">{attendanceRate}%</div>
            <Progress value={attendanceRate} className="h-2" />
            <p className="text-xs text-muted-foreground mt-2">
              This term
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Fee Balance</CardTitle>
            <Wallet className="w-5 h-5 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl mb-2">
              KSh {myFeeRecord ? myFeeRecord.balance.toLocaleString() : '0'}
            </div>
            <p className="text-xs text-muted-foreground">
              {myFeeRecord?.balance === 0 ? 'Fully paid' : 'Outstanding balance'}
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Reports Available</CardTitle>
            <FileText className="w-5 h-5 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl mb-2">3</div>
            <p className="text-xs text-muted-foreground">
              Term reports ready
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Recent Attendance */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Attendance</CardTitle>
          <CardDescription>Last 7 days</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'].map((day, index) => (
              <div key={day} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${index < 4 ? 'bg-green-500' : 'bg-red-500'}`}></div>
                  <div>
                    <p className="text-sm font-medium">{day}</p>
                    <p className="text-xs text-muted-foreground">January {10 + index}, 2024</p>
                  </div>
                </div>
                {index < 4 ? (
                  <Badge className="bg-green-500 gap-1">
                    <CheckCircle className="w-3 h-3" />
                    Present
                  </Badge>
                ) : index === 4 ? (
                  <Badge className="bg-red-500 gap-1">
                    <XCircle className="w-3 h-3" />
                    Absent
                  </Badge>
                ) : (
                  <Badge className="bg-yellow-500 gap-1">
                    <Clock className="w-3 h-3" />
                    Late
                  </Badge>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Fee Statement */}
      {myFeeRecord && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Fee Statement</CardTitle>
                <CardDescription>Current term fees</CardDescription>
              </div>
              <Button variant="outline" size="sm" className="gap-2">
                <Download className="w-4 h-4" />
                Download
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Total Fees</p>
                  <p className="text-lg mt-1">KSh {myFeeRecord.totalFees.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Paid</p>
                  <p className="text-lg mt-1 text-green-600">KSh {myFeeRecord.paidAmount.toLocaleString()}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Balance</p>
                  <p className="text-lg mt-1 text-orange-600">KSh {myFeeRecord.balance.toLocaleString()}</p>
                </div>
              </div>
              <Progress value={(myFeeRecord.paidAmount / myFeeRecord.totalFees) * 100} className="h-2" />
              <div className="pt-4">
                <p className="text-sm font-medium mb-3">Recent Payments</p>
                {myFeeRecord.payments.map(payment => (
                  <div key={payment.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="text-sm">
                        {new Date(payment.date).toLocaleDateString('en-KE', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                        })}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {payment.method} {payment.reference && `- ${payment.reference}`}
                      </p>
                    </div>
                    <p className="font-medium">KSh {payment.amount.toLocaleString()}</p>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Announcements */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>School Announcements</CardTitle>
              <CardDescription>Important updates and notices</CardDescription>
            </div>
            <Bell className="w-5 h-5 text-muted-foreground" />
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {announcements.map(announcement => (
              <div key={announcement.id} className="p-4 border rounded-lg">
                <div className="flex items-start justify-between mb-2">
                  <h4 className="font-medium">{announcement.title}</h4>
                  <Badge variant={announcement.priority === 'high' ? 'destructive' : 'secondary'}>
                    {announcement.priority}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-2">{announcement.message}</p>
                <p className="text-xs text-muted-foreground">
                  {new Date(announcement.date).toLocaleDateString('en-KE', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
