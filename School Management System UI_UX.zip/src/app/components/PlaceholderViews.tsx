import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { FileText, Calendar, Users, Settings } from 'lucide-react';

export function ExamsReports() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl">Exams & Reports</h1>
        <p className="text-muted-foreground mt-1">CBC aligned assessments and report cards</p>
      </div>
      <Card className="flex flex-col items-center justify-center h-96">
        <CardContent className="text-center pt-6">
          <FileText className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <CardTitle className="mb-2">Exams & Reports Module</CardTitle>
          <CardDescription>
            This module will include CBC assessment input, learning areas tracking,<br />
            automatic report card generation, and performance analytics.
          </CardDescription>
        </CardContent>
      </Card>
    </div>
  );
}

export function AttendanceModule() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl">Attendance Management</h1>
        <p className="text-muted-foreground mt-1">Track daily attendance and generate reports</p>
      </div>
      <Card className="flex flex-col items-center justify-center h-96">
        <CardContent className="text-center pt-6">
          <Calendar className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <CardTitle className="mb-2">Attendance Module</CardTitle>
          <CardDescription>
            This module will include daily attendance marking, student status indicators,<br />
            monthly analytics, and attendance reports.
          </CardDescription>
        </CardContent>
      </Card>
    </div>
  );
}

export function StaffRecords() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl">Staff Records</h1>
        <p className="text-muted-foreground mt-1">Manage teacher profiles and employment records</p>
      </div>
      <Card className="flex flex-col items-center justify-center h-96">
        <CardContent className="text-center pt-6">
          <Users className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <CardTitle className="mb-2">Staff Records Module</CardTitle>
          <CardDescription>
            This module will include teacher profiles, TSC number management,<br />
            subject assignments, and employment status tracking.
          </CardDescription>
        </CardContent>
      </Card>
    </div>
  );
}

export function SettingsView() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl">Settings</h1>
        <p className="text-muted-foreground mt-1">Configure system preferences and user settings</p>
      </div>
      <Card className="flex flex-col items-center justify-center h-96">
        <CardContent className="text-center pt-6">
          <Settings className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <CardTitle className="mb-2">Settings Module</CardTitle>
          <CardDescription>
            This module will include user preferences, school configuration,<br />
            academic year settings, and system administration.
          </CardDescription>
        </CardContent>
      </Card>
    </div>
  );
}
