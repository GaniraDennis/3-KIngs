import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/app/components/ui/select';
import { GraduationCap, Shield, Users, Wallet, Package } from 'lucide-react';
import { useApp, UserRole } from '@/app/context/AppContext';

export function LoginScreen() {
  const [role, setRole] = useState<UserRole>('administrator');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const { setCurrentUser, setCurrentView } = useApp();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    const roleNames = {
      administrator: 'Admin User',
      teacher: 'Grace Njeri',
      parent: 'Peter Kamau',
      bursar: 'Accounts Officer',
      inventory: 'Inventory Manager',
    };

    setCurrentUser({ role, name: roleNames[role] });
    setCurrentView('dashboard');
  };

  const roleIcons = {
    administrator: <Shield className="w-5 h-5" />,
    teacher: <GraduationCap className="w-5 h-5" />,
    parent: <Users className="w-5 h-5" />,
    bursar: <Wallet className="w-5 h-5" />,
    inventory: <Package className="w-5 h-5" />,
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary via-primary to-[#1a3550] p-4">
      <Card className="w-full max-w-md shadow-2xl">
        <CardHeader className="text-center space-y-4">
          <div className="mx-auto w-20 h-20 bg-primary rounded-full flex items-center justify-center">
            <GraduationCap className="w-12 h-12 text-white" />
          </div>
          <div>
            <CardTitle className="text-2xl">Three Kings Academy</CardTitle>
            <CardDescription className="text-sm mt-1">Excellence in Foundation Education</CardDescription>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLogin} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="role">Select Role</Label>
              <Select value={role} onValueChange={(value) => setRole(value as UserRole)}>
                <SelectTrigger id="role">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="administrator">
                    <div className="flex items-center gap-2">
                      {roleIcons.administrator}
                      <span>Administrator</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="teacher">
                    <div className="flex items-center gap-2">
                      {roleIcons.teacher}
                      <span>Teacher</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="parent">
                    <div className="flex items-center gap-2">
                      {roleIcons.parent}
                      <span>Parent/Guardian</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="bursar">
                    <div className="flex items-center gap-2">
                      {roleIcons.bursar}
                      <span>Accounts/Bursar</span>
                    </div>
                  </SelectItem>
                  <SelectItem value="inventory">
                    <div className="flex items-center gap-2">
                      {roleIcons.inventory}
                      <span>Inventory Manager</span>
                    </div>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
              Sign In
            </Button>

            <div className="text-center">
              <Button variant="link" className="text-sm text-muted-foreground">
                Forgot password?
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
