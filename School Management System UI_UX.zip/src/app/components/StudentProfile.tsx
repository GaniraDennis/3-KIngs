import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/app/components/ui/dialog';
import { Button } from '@/app/components/ui/button';
import { Badge } from '@/app/components/ui/badge';
import { Separator } from '@/app/components/ui/separator';
import { Avatar, AvatarFallback } from '@/app/components/ui/avatar';
import { Card, CardContent } from '@/app/components/ui/card';
import { 
  User, 
  Phone, 
  Mail, 
  Calendar, 
  MapPin, 
  FileText, 
  Heart,
  Edit
} from 'lucide-react';
import { Student } from '@/app/context/AppContext';

interface StudentProfileProps {
  student: Student;
  open: boolean;
  onClose: () => void;
}

export function StudentProfile({ student, open, onClose }: StudentProfileProps) {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-KE', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active':
        return 'bg-green-500';
      case 'Transferred':
        return 'bg-blue-500';
      case 'Expelled':
        return 'bg-red-500';
      case 'Alumni':
        return 'bg-purple-500';
      default:
        return 'bg-gray-500';
    }
  };

  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Student Profile</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Header Section */}
          <div className="flex flex-col md:flex-row gap-6">
            <Avatar className="h-24 w-24">
              <AvatarFallback className="bg-primary text-primary-foreground text-2xl">
                {student.firstName[0]}{student.lastName[0]}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-2xl">
                    {student.firstName} {student.lastName} {student.otherNames}
                  </h3>
                  <p className="text-sm text-muted-foreground font-mono mt-1">
                    {student.admissionNumber}
                  </p>
                </div>
                <Badge className={getStatusColor(student.status)}>
                  {student.status}
                </Badge>
              </div>
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div className="flex items-center gap-2 text-sm">
                  <User className="w-4 h-4 text-muted-foreground" />
                  <span>{student.gender}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Calendar className="w-4 h-4 text-muted-foreground" />
                  <span>{formatDate(student.dateOfBirth)}</span>
                </div>
              </div>
            </div>
          </div>

          <Separator />

          {/* Academic Information */}
          <div>
            <h4 className="text-lg mb-3">Academic Information</h4>
            <Card>
              <CardContent className="pt-6">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Grade</p>
                    <p className="text-base mt-1">{student.grade}</p>
                  </div>
                  {student.stream && (
                    <div>
                      <p className="text-sm text-muted-foreground">Stream</p>
                      <p className="text-base mt-1">{student.stream}</p>
                    </div>
                  )}
                  <div>
                    <p className="text-sm text-muted-foreground">Admission Date</p>
                    <p className="text-base mt-1">{formatDate(student.admissionDate)}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Student Status</p>
                    <p className="text-base mt-1">{student.status}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Parent/Guardian Information */}
          <div>
            <h4 className="text-lg mb-3">Parent/Guardian Information</h4>
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <User className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">Name</p>
                      <p className="text-base">{student.parentName}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">Phone</p>
                      <p className="text-base">{student.parentPhone}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <div>
                      <p className="text-sm text-muted-foreground">Email</p>
                      <p className="text-base">{student.parentEmail}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Medical Information */}
          {student.medicalInfo && (
            <div>
              <h4 className="text-lg mb-3">Medical Information</h4>
              <Card>
                <CardContent className="pt-6">
                  <div className="flex items-start gap-3">
                    <Heart className="w-4 h-4 text-muted-foreground mt-1" />
                    <div>
                      <p className="text-sm text-muted-foreground">Notes</p>
                      <p className="text-base">{student.medicalInfo}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Documents */}
          <div>
            <h4 className="text-lg mb-3">Documents</h4>
            <Card>
              <CardContent className="pt-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <FileText className="w-5 h-5 text-muted-foreground" />
                      <div>
                        <p className="text-sm">Birth Certificate</p>
                        <p className="text-xs text-muted-foreground">
                          {student.birthCertificateUrl ? 'Uploaded' : 'Not uploaded'}
                        </p>
                      </div>
                    </div>
                    {student.birthCertificateUrl && (
                      <Button variant="outline" size="sm">
                        View
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
            <Button className="gap-2">
              <Edit className="w-4 h-4" />
              Edit Profile
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
