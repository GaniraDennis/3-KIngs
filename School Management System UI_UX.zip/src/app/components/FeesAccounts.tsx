import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Badge } from '@/app/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/app/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/app/components/ui/dialog';
import { Avatar, AvatarFallback } from '@/app/components/ui/avatar';
import { Search, Eye, Download, Wallet, TrendingUp, AlertCircle } from 'lucide-react';
import { useApp } from '@/app/context/AppContext';

export function FeesAccounts() {
  const { students, feeRecords } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRecord, setSelectedRecord] = useState<string | null>(null);

  const getStudentName = (studentId: string) => {
    const student = students.find(s => s.id === studentId);
    return student ? `${student.firstName} ${student.lastName}` : 'Unknown';
  };

  const getStudent = (studentId: string) => {
    return students.find(s => s.id === studentId);
  };

  const selectedFeeRecord = feeRecords.find(r => r.id === selectedRecord);
  const selectedStudent = selectedFeeRecord ? getStudent(selectedFeeRecord.studentId) : null;

  const totalExpected = feeRecords.reduce((sum, r) => sum + r.totalFees, 0);
  const totalCollected = feeRecords.reduce((sum, r) => sum + r.paidAmount, 0);
  const totalBalance = feeRecords.reduce((sum, r) => sum + r.balance, 0);

  const filteredRecords = feeRecords.filter(record => {
    const studentName = getStudentName(record.studentId).toLowerCase();
    return studentName.includes(searchQuery.toLowerCase());
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl">Fees & Accounts</h1>
        <p className="text-muted-foreground mt-1">Manage school fees and payment records</p>
      </div>

      {/* Summary Cards */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Total Expected</CardTitle>
            <Wallet className="w-5 h-5 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">KSh {totalExpected.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground mt-1">
              Current term fees
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Total Collected</CardTitle>
            <TrendingUp className="w-5 h-5 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">KSh {totalCollected.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {((totalCollected / totalExpected) * 100).toFixed(1)}% collection rate
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm text-muted-foreground">Outstanding Balance</CardTitle>
            <AlertCircle className="w-5 h-5 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl">KSh {totalBalance.toLocaleString()}</div>
            <p className="text-xs text-muted-foreground mt-1">
              {feeRecords.filter(r => r.balance > 0).length} students pending
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Fee Records Table */}
      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <CardTitle>Fee Records</CardTitle>
              <CardDescription>Student payment history and balances</CardDescription>
            </div>
            <div className="relative w-full md:w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search student..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Term</TableHead>
                  <TableHead>Total Fees</TableHead>
                  <TableHead>Paid Amount</TableHead>
                  <TableHead>Balance</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRecords.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      No records found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredRecords.map((record) => {
                    const student = getStudent(record.studentId);
                    return (
                      <TableRow key={record.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar className="h-8 w-8">
                              <AvatarFallback className="bg-primary text-primary-foreground text-xs">
                                {student && student.firstName[0]}{student && student.lastName[0]}
                              </AvatarFallback>
                            </Avatar>
                            <span>{getStudentName(record.studentId)}</span>
                          </div>
                        </TableCell>
                        <TableCell>{record.term} {record.year}</TableCell>
                        <TableCell>KSh {record.totalFees.toLocaleString()}</TableCell>
                        <TableCell>KSh {record.paidAmount.toLocaleString()}</TableCell>
                        <TableCell>KSh {record.balance.toLocaleString()}</TableCell>
                        <TableCell>
                          {record.balance === 0 ? (
                            <Badge className="bg-green-500">Paid</Badge>
                          ) : record.paidAmount > 0 ? (
                            <Badge className="bg-yellow-500">Partial</Badge>
                          ) : (
                            <Badge className="bg-red-500">Unpaid</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => setSelectedRecord(record.id)}
                            >
                              <Eye className="w-4 h-4" />
                            </Button>
                            <Button variant="ghost" size="icon">
                              <Download className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Fee Statement Dialog */}
      <Dialog open={selectedRecord !== null} onOpenChange={(open) => !open && setSelectedRecord(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Fee Statement</DialogTitle>
            <DialogDescription>Detailed payment history and balance</DialogDescription>
          </DialogHeader>
          {selectedFeeRecord && selectedStudent && (
            <div className="space-y-6">
              {/* Student Info */}
              <div className="flex items-center gap-4">
                <Avatar className="h-16 w-16">
                  <AvatarFallback className="bg-primary text-primary-foreground">
                    {selectedStudent.firstName[0]}{selectedStudent.lastName[0]}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <h3 className="text-lg">{selectedStudent.firstName} {selectedStudent.lastName}</h3>
                  <p className="text-sm text-muted-foreground">{selectedStudent.admissionNumber}</p>
                  <p className="text-sm text-muted-foreground">{selectedStudent.grade} {selectedStudent.stream}</p>
                </div>
              </div>

              {/* Fee Summary */}
              <Card>
                <CardContent className="pt-6">
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <p className="text-sm text-muted-foreground">Total Fees</p>
                      <p className="text-xl mt-1">KSh {selectedFeeRecord.totalFees.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Paid Amount</p>
                      <p className="text-xl mt-1 text-green-600">KSh {selectedFeeRecord.paidAmount.toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Balance</p>
                      <p className="text-xl mt-1 text-orange-600">KSh {selectedFeeRecord.balance.toLocaleString()}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Payment History */}
              <div>
                <h4 className="text-sm mb-3">Payment History</h4>
                <div className="space-y-2">
                  {selectedFeeRecord.payments.map((payment) => (
                    <div key={payment.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="text-sm">
                          {new Date(payment.date).toLocaleDateString('en-KE', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                          })}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {payment.method} {payment.reference && `- ${payment.reference}`}
                        </p>
                      </div>
                      <p className="font-medium">KSh {payment.amount.toLocaleString()}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                <Button variant="outline" className="flex-1 gap-2">
                  <Download className="w-4 h-4" />
                  Download PDF
                </Button>
                <Button className="flex-1">
                  Record Payment
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
