import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Badge } from '@/app/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/app/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/app/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/app/components/ui/dialog';
import { Avatar, AvatarFallback } from '@/app/components/ui/avatar';
import { Search, Filter, Edit, UserX, Archive, Eye } from 'lucide-react';
import { useApp, Student, StudentStatus } from '@/app/context/AppContext';
import { StudentProfile } from '@/app/components/StudentProfile';

export function StudentManagement() {
  const { students, updateStudent } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [filterGrade, setFilterGrade] = useState('all');
  const [filterStatus, setFilterStatus] = useState<StudentStatus | 'all'>('all');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [showProfile, setShowProfile] = useState(false);
  const [actionDialog, setActionDialog] = useState<{
    open: boolean;
    type: 'transfer' | 'expel' | 'archive' | null;
    student: Student | null;
  }>({ open: false, type: null, student: null });

  const filteredStudents = students.filter(student => {
    const matchesSearch = 
      student.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.admissionNumber.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesGrade = filterGrade === 'all' || student.grade === filterGrade;
    const matchesStatus = filterStatus === 'all' || student.status === filterStatus;
    
    return matchesSearch && matchesGrade && matchesStatus;
  });

  const grades = ['Daycare', 'PP1', 'PP2', 'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6'];

  const getStatusColor = (status: StudentStatus) => {
    switch (status) {
      case 'Active':
        return 'bg-green-500';
      case 'Transferred':
        return 'bg-blue-500';
      case 'Expelled':
        return 'bg-red-500';
      case 'Alumni':
        return 'bg-purple-500';
      default:
        return 'bg-gray-500';
    }
  };

  const handleAction = (type: 'transfer' | 'expel' | 'archive', student: Student) => {
    setActionDialog({ open: true, type, student });
  };

  const confirmAction = () => {
    if (actionDialog.student && actionDialog.type) {
      const statusMap = {
        transfer: 'Transferred' as StudentStatus,
        expel: 'Expelled' as StudentStatus,
        archive: 'Alumni' as StudentStatus,
      };
      
      updateStudent(actionDialog.student.id, {
        status: statusMap[actionDialog.type],
      });
    }
    setActionDialog({ open: false, type: null, student: null });
  };

  const viewProfile = (student: Student) => {
    setSelectedStudent(student);
    setShowProfile(true);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl">Student Management</h1>
        <p className="text-muted-foreground mt-1">Manage all student records and information</p>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Filters & Search</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="relative md:col-span-2">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Search by name or admission number..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
            <Select value={filterGrade} onValueChange={setFilterGrade}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by Grade" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Grades</SelectItem>
                {grades.map(grade => (
                  <SelectItem key={grade} value={grade}>{grade}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={(value) => setFilterStatus(value as StudentStatus | 'all')}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Active">Active</SelectItem>
                <SelectItem value="Transferred">Transferred</SelectItem>
                <SelectItem value="Expelled">Expelled</SelectItem>
                <SelectItem value="Alumni">Alumni</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Students Table */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Students ({filteredStudents.length})</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student</TableHead>
                  <TableHead>Admission No.</TableHead>
                  <TableHead>Grade/Stream</TableHead>
                  <TableHead>Parent Contact</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredStudents.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      No students found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredStudents.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell>
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarFallback className="bg-primary text-primary-foreground">
                              {student.firstName[0]}{student.lastName[0]}
                            </AvatarFallback>
                          </Avatar>
                          <div>
                            <div className="font-medium">
                              {student.firstName} {student.lastName}
                            </div>
                            <div className="text-sm text-muted-foreground">{student.gender}</div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="font-mono text-sm">{student.admissionNumber}</TableCell>
                      <TableCell>
                        {student.grade} {student.stream && `- ${student.stream}`}
                      </TableCell>
                      <TableCell>
                        <div className="text-sm">
                          <div>{student.parentName}</div>
                          <div className="text-muted-foreground">{student.parentPhone}</div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(student.status)}>
                          {student.status}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-2">
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => viewProfile(student)}
                          >
                            <Eye className="w-4 h-4" />
                          </Button>
                          {student.status === 'Active' && (
                            <>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleAction('transfer', student)}
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleAction('expel', student)}
                              >
                                <UserX className="w-4 h-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="icon"
                                onClick={() => handleAction('archive', student)}
                              >
                                <Archive className="w-4 h-4" />
                              </Button>
                            </>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Action Confirmation Dialog */}
      <Dialog open={actionDialog.open} onOpenChange={(open) => !open && setActionDialog({ open: false, type: null, student: null })}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Action</DialogTitle>
            <DialogDescription>
              {actionDialog.type === 'transfer' && 'Are you sure you want to mark this student as transferred?'}
              {actionDialog.type === 'expel' && 'Are you sure you want to mark this student as expelled?'}
              {actionDialog.type === 'archive' && 'Are you sure you want to archive this student?'}
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setActionDialog({ open: false, type: null, student: null })}>
              Cancel
            </Button>
            <Button onClick={confirmAction}>
              Confirm
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Student Profile Dialog */}
      {selectedStudent && (
        <StudentProfile
          student={selectedStudent}
          open={showProfile}
          onClose={() => {
            setShowProfile(false);
            setSelectedStudent(null);
          }}
        />
      )}
    </div>
  );
}
