import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/app/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/app/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/app/components/ui/tabs';
import { Textarea } from '@/app/components/ui/textarea';
import { Badge } from '@/app/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/app/components/ui/dialog';
import { useApp, ExamResult, LearningArea } from '@/app/context/AppContext';
import {
  FileText,
  Download,
  Plus,
  Search,
  TrendingUp,
  Award,
  BarChart3,
  Eye,
} from 'lucide-react';
import { toast } from 'sonner';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

const cbcLearningAreas = [
  'Mathematics',
  'English',
  'Kiswahili',
  'Science and Technology',
  'Social Studies',
  'Creative Arts',
  'Physical Education',
  'Religious Education',
];

const cbcGradingScale = [
  { grade: 'Exceeds Expectations', min: 80, max: 100, description: 'Outstanding performance' },
  { grade: 'Meets Expectations', min: 60, max: 79, description: 'Good performance' },
  { grade: 'Approaches Expectations', min: 40, max: 59, description: 'Satisfactory performance' },
  { grade: 'Below Expectations', min: 0, max: 39, description: 'Needs improvement' },
];

export function ExamsReportsModule() {
  const { students, examResults, addExamResult, academicTerms } = useApp();
  const [selectedStudent, setSelectedStudent] = useState('');
  const [selectedTerm, setSelectedTerm] = useState('');
  const [selectedGrade, setSelectedGrade] = useState('');
  const [learningAreaScores, setLearningAreaScores] = useState<Record<string, number>>({});
  const [teacherRemarks, setTeacherRemarks] = useState('');
  const [principalRemarks, setPrincipalRemarks] = useState('');
  const [searchQuery, setSearchQuery] = useState('');
  const [showReportDialog, setShowReportDialog] = useState(false);
  const [selectedReport, setSelectedReport] = useState<ExamResult | null>(null);

  const activeStudents = students.filter((s) => s.status === 'Active' && !s.archived);

  const getGradeFromScore = (score: number): string => {
    for (const scale of cbcGradingScale) {
      if (score >= scale.min && score <= scale.max) {
        return scale.grade;
      }
    }
    return 'Below Expectations';
  };

  const getCompetency = (score: number): string => {
    if (score >= 80) return 'Excellent';
    if (score >= 60) return 'Good';
    if (score >= 40) return 'Fair';
    return 'Needs Support';
  };

  const handleScoreChange = (area: string, score: string) => {
    const numScore = parseFloat(score);
    if (!isNaN(numScore) && numScore >= 0 && numScore <= 100) {
      setLearningAreaScores({
        ...learningAreaScores,
        [area]: numScore,
      });
    }
  };

  const handleSubmitResult = () => {
    if (!selectedStudent || !selectedTerm || Object.keys(learningAreaScores).length === 0) {
      toast.error('Please fill in all required fields');
      return;
    }

    const student = activeStudents.find((s) => s.id === selectedStudent);
    if (!student) return;

    const learningAreas: LearningArea[] = Object.entries(learningAreaScores).map(
      ([name, score]) => ({
        name,
        score,
        grade: getGradeFromScore(score),
        competency: getCompetency(score),
      })
    );

    const term = academicTerms.find((t) => t.id === selectedTerm);

    const result: ExamResult = {
      id: Date.now().toString(),
      studentId: selectedStudent,
      term: term?.name || '',
      year: term?.year || '',
      grade: student.grade,
      learningAreas,
      teacherRemarks,
      principalRemarks,
      generatedDate: new Date().toISOString(),
    };

    addExamResult(result);
    toast.success('Exam results submitted successfully');
    
    // Reset form
    setSelectedStudent('');
    setLearningAreaScores({});
    setTeacherRemarks('');
    setPrincipalRemarks('');
  };

  const viewReport = (result: ExamResult) => {
    setSelectedReport(result);
    setShowReportDialog(true);
  };

  const calculateAverage = (learningAreas: LearningArea[]) => {
    if (learningAreas.length === 0) return 0;
    const sum = learningAreas.reduce((acc, area) => acc + area.score, 0);
    return (sum / learningAreas.length).toFixed(1);
  };

  const filteredStudents = activeStudents.filter((student) => {
    const matchesSearch =
      student.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.admissionNumber.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGrade = !selectedGrade || student.grade === selectedGrade;
    return matchesSearch && matchesGrade;
  });

  // Mock performance data for charts
  const performanceData = [
    { subject: 'Math', score: 85 },
    { subject: 'English', score: 78 },
    { subject: 'Kiswahili', score: 72 },
    { subject: 'Science', score: 88 },
    { subject: 'Social Studies', score: 75 },
    { subject: 'Creative Arts', score: 90 },
  ];

  const termProgressData = [
    { term: 'Term 1', average: 75 },
    { term: 'Term 2', average: 78 },
    { term: 'Term 3', average: 82 },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl">Exams & Reports</h1>
          <p className="text-muted-foreground mt-1">
            CBC-aligned assessments and report card generation
          </p>
        </div>
        <Button className="gap-2">
          <Download className="w-4 h-4" />
          Bulk Export Reports
        </Button>
      </div>

      <Tabs defaultValue="enter" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4 lg:w-auto">
          <TabsTrigger value="enter" className="gap-2">
            <Plus className="w-4 h-4" />
            Enter Results
          </TabsTrigger>
          <TabsTrigger value="reports" className="gap-2">
            <FileText className="w-4 h-4" />
            Reports
          </TabsTrigger>
          <TabsTrigger value="analytics" className="gap-2">
            <BarChart3 className="w-4 h-4" />
            Analytics
          </TabsTrigger>
          <TabsTrigger value="grading" className="gap-2">
            <Award className="w-4 h-4" />
            Grading Scale
          </TabsTrigger>
        </TabsList>

        <TabsContent value="enter" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Enter Exam Results</CardTitle>
              <CardDescription>
                Input CBC learning area scores and generate report cards
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Student Selection */}
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>Select Student *</Label>
                  <Select value={selectedStudent} onValueChange={setSelectedStudent}>
                    <SelectTrigger>
                      <SelectValue placeholder="Choose a student" />
                    </SelectTrigger>
                    <SelectContent>
                      {activeStudents.map((student) => (
                        <SelectItem key={student.id} value={student.id}>
                          {student.firstName} {student.lastName} - {student.admissionNumber}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Academic Term *</Label>
                  <Select value={selectedTerm} onValueChange={setSelectedTerm}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select term" />
                    </SelectTrigger>
                    <SelectContent>
                      {academicTerms.map((term) => (
                        <SelectItem key={term.id} value={term.id}>
                          {term.name} {term.year}
                          {term.isCurrent && ' (Current)'}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Learning Areas Scores */}
              <div>
                <h3 className="font-semibold mb-3">CBC Learning Areas</h3>
                <div className="grid gap-4 md:grid-cols-2">
                  {cbcLearningAreas.map((area) => (
                    <div key={area} className="space-y-2">
                      <Label>{area}</Label>
                      <div className="flex gap-2 items-center">
                        <Input
                          type="number"
                          min="0"
                          max="100"
                          placeholder="Score (0-100)"
                          value={learningAreaScores[area] || ''}
                          onChange={(e) => handleScoreChange(area, e.target.value)}
                          className="flex-1"
                        />
                        {learningAreaScores[area] !== undefined && (
                          <Badge
                            className={
                              learningAreaScores[area] >= 80
                                ? 'bg-green-500'
                                : learningAreaScores[area] >= 60
                                ? 'bg-blue-500'
                                : learningAreaScores[area] >= 40
                                ? 'bg-yellow-500'
                                : 'bg-red-500'
                            }
                          >
                            {getGradeFromScore(learningAreaScores[area])}
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Remarks */}
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label>Teacher's Remarks</Label>
                  <Textarea
                    placeholder="Enter teacher's comments on student performance..."
                    value={teacherRemarks}
                    onChange={(e) => setTeacherRemarks(e.target.value)}
                    rows={4}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Principal's Remarks</Label>
                  <Textarea
                    placeholder="Enter principal's comments..."
                    value={principalRemarks}
                    onChange={(e) => setPrincipalRemarks(e.target.value)}
                    rows={4}
                  />
                </div>
              </div>

              {/* Submit Button */}
              <div className="flex justify-end gap-2">
                <Button variant="outline">Save Draft</Button>
                <Button onClick={handleSubmitResult} className="gap-2">
                  <FileText className="w-4 h-4" />
                  Generate Report Card
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="reports" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Generated Reports</CardTitle>
              <CardDescription>View and download student report cards</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Filters */}
              <div className="grid gap-4 md:grid-cols-3">
                <div className="space-y-2">
                  <Label>Search Student</Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      placeholder="Name or admission no."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Filter by Grade</Label>
                  <Select value={selectedGrade} onValueChange={setSelectedGrade}>
                    <SelectTrigger>
                      <SelectValue placeholder="All grades" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All Grades</SelectItem>
                      <SelectItem value="Grade 1">Grade 1</SelectItem>
                      <SelectItem value="Grade 2">Grade 2</SelectItem>
                      <SelectItem value="Grade 3">Grade 3</SelectItem>
                      <SelectItem value="Grade 4">Grade 4</SelectItem>
                      <SelectItem value="Grade 5">Grade 5</SelectItem>
                      <SelectItem value="Grade 6">Grade 6</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Term</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="All terms" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Terms</SelectItem>
                      {academicTerms.map((term) => (
                        <SelectItem key={term.id} value={term.id}>
                          {term.name} {term.year}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Reports Table */}
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Student</TableHead>
                      <TableHead>Grade</TableHead>
                      <TableHead>Term</TableHead>
                      <TableHead>Average</TableHead>
                      <TableHead>Performance</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {examResults.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                          <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
                          <p>No reports generated yet</p>
                        </TableCell>
                      </TableRow>
                    ) : (
                      examResults.map((result) => {
                        const student = activeStudents.find((s) => s.id === result.studentId);
                        const average = calculateAverage(result.learningAreas);
                        return (
                          <TableRow key={result.id}>
                            <TableCell>
                              <div>
                                <div className="font-medium">
                                  {student?.firstName} {student?.lastName}
                                </div>
                                <div className="text-xs text-muted-foreground">
                                  {student?.admissionNumber}
                                </div>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">{result.grade}</Badge>
                            </TableCell>
                            <TableCell>
                              {result.term} {result.year}
                            </TableCell>
                            <TableCell className="font-semibold">
                              {average}%
                            </TableCell>
                            <TableCell>
                              <Badge
                                className={
                                  parseFloat(average) >= 80
                                    ? 'bg-green-500'
                                    : parseFloat(average) >= 60
                                    ? 'bg-blue-500'
                                    : parseFloat(average) >= 40
                                    ? 'bg-yellow-500'
                                    : 'bg-red-500'
                                }
                              >
                                {getGradeFromScore(parseFloat(average))}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => viewReport(result)}
                                  className="gap-1"
                                >
                                  <Eye className="w-3 h-3" />
                                  View
                                </Button>
                                <Button size="sm" variant="outline" className="gap-1">
                                  <Download className="w-3 h-3" />
                                  PDF
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Subject Performance</CardTitle>
                <CardDescription>Average scores across learning areas</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={performanceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="subject" angle={-45} textAnchor="end" height={80} />
                    <YAxis domain={[0, 100]} />
                    <Tooltip />
                    <Bar dataKey="score" fill="#0B1C2D" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Term Progress</CardTitle>
                <CardDescription>Average performance across terms</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={termProgressData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="term" />
                    <YAxis domain={[0, 100]} />
                    <Tooltip />
                    <Legend />
                    <Line
                      type="monotone"
                      dataKey="average"
                      stroke="#d4af37"
                      strokeWidth={2}
                      name="Class Average"
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle>Competency Radar</CardTitle>
                <CardDescription>
                  CBC competency distribution across learning areas
                </CardDescription>
              </CardHeader>
              <CardContent className="flex justify-center">
                <ResponsiveContainer width="100%" height={400}>
                  <RadarChart data={performanceData}>
                    <PolarGrid />
                    <PolarAngleAxis dataKey="subject" />
                    <PolarRadiusAxis domain={[0, 100]} />
                    <Radar
                      name="Performance"
                      dataKey="score"
                      stroke="#0B1C2D"
                      fill="#0B1C2D"
                      fillOpacity={0.6}
                    />
                    <Tooltip />
                  </RadarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="grading" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>CBC Grading Scale</CardTitle>
              <CardDescription>
                Competency-Based Curriculum grading system for primary education
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {cbcGradingScale.map((scale, index) => (
                  <div
                    key={index}
                    className="p-4 border rounded-lg hover:bg-secondary/50 transition-colors"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold text-lg">{scale.grade}</h3>
                      <Badge
                        className={
                          scale.min >= 80
                            ? 'bg-green-500'
                            : scale.min >= 60
                            ? 'bg-blue-500'
                            : scale.min >= 40
                            ? 'bg-yellow-500'
                            : 'bg-red-500'
                        }
                      >
                        {scale.min}% - {scale.max}%
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">{scale.description}</p>
                  </div>
                ))}
              </div>

              <div className="mt-6 p-4 bg-secondary/30 rounded-lg">
                <h4 className="font-semibold mb-2">About CBC Grading</h4>
                <p className="text-sm text-muted-foreground">
                  The Competency-Based Curriculum (CBC) focuses on developing learner
                  competencies rather than just knowledge. The grading system assesses how well
                  students demonstrate skills, knowledge, and values in each learning area.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Report Preview Dialog */}
      <Dialog open={showReportDialog} onOpenChange={setShowReportDialog}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Student Report Card</DialogTitle>
            <DialogDescription>
              {selectedReport &&
                (() => {
                  const student = activeStudents.find(
                    (s) => s.id === selectedReport.studentId
                  );
                  return `${student?.firstName} ${student?.lastName} - ${selectedReport.term} ${selectedReport.year}`;
                })()}
            </DialogDescription>
          </DialogHeader>
          
          {selectedReport && (() => {
            const student = activeStudents.find((s) => s.id === selectedReport.studentId);
            return (
              <div className="space-y-6">
                {/* Header */}
                <div className="text-center border-b pb-4">
                  <h2 className="text-2xl font-bold text-primary">Three Kings Academy</h2>
                  <p className="text-sm text-muted-foreground">Excellence in Foundation Education</p>
                  <h3 className="text-xl font-semibold mt-2">Progress Report Card</h3>
                </div>

                {/* Student Info */}
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <strong>Student Name:</strong> {student?.firstName} {student?.lastName}
                  </div>
                  <div>
                    <strong>Admission No:</strong> {student?.admissionNumber}
                  </div>
                  <div>
                    <strong>Grade:</strong> {selectedReport.grade}
                  </div>
                  <div>
                    <strong>Term:</strong> {selectedReport.term} {selectedReport.year}
                  </div>
                </div>

                {/* Learning Areas */}
                <div>
                  <h4 className="font-semibold mb-3">Learning Areas Performance</h4>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Learning Area</TableHead>
                        <TableHead>Score</TableHead>
                        <TableHead>Grade</TableHead>
                        <TableHead>Competency</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedReport.learningAreas.map((area, index) => (
                        <TableRow key={index}>
                          <TableCell>{area.name}</TableCell>
                          <TableCell className="font-semibold">{area.score}%</TableCell>
                          <TableCell>
                            <Badge
                              className={
                                area.score >= 80
                                  ? 'bg-green-500'
                                  : area.score >= 60
                                  ? 'bg-blue-500'
                                  : area.score >= 40
                                  ? 'bg-yellow-500'
                                  : 'bg-red-500'
                              }
                            >
                              {area.grade}
                            </Badge>
                          </TableCell>
                          <TableCell>{area.competency}</TableCell>
                        </TableRow>
                      ))}
                      <TableRow className="font-semibold bg-secondary">
                        <TableCell>Average</TableCell>
                        <TableCell>{calculateAverage(selectedReport.learningAreas)}%</TableCell>
                        <TableCell colSpan={2}>
                          <Badge className="bg-primary">
                            {getGradeFromScore(
                              parseFloat(calculateAverage(selectedReport.learningAreas))
                            )}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    </TableBody>
                  </Table>
                </div>

                {/* Remarks */}
                {(selectedReport.teacherRemarks || selectedReport.principalRemarks) && (
                  <div className="space-y-3">
                    {selectedReport.teacherRemarks && (
                      <div className="p-3 border rounded-lg">
                        <strong className="text-sm">Teacher's Remarks:</strong>
                        <p className="text-sm text-muted-foreground mt-1">
                          {selectedReport.teacherRemarks}
                        </p>
                      </div>
                    )}
                    {selectedReport.principalRemarks && (
                      <div className="p-3 border rounded-lg">
                        <strong className="text-sm">Principal's Remarks:</strong>
                        <p className="text-sm text-muted-foreground mt-1">
                          {selectedReport.principalRemarks}
                        </p>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })()}

          <DialogFooter>
            <Button variant="outline" onClick={() => setShowReportDialog(false)}>
              Close
            </Button>
            <Button className="gap-2">
              <Download className="w-4 h-4" />
              Download PDF
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
