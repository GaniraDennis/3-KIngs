import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/app/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/app/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/app/components/ui/tabs';
import { Textarea } from '@/app/components/ui/textarea';
import { Badge } from '@/app/components/ui/badge';
import { Checkbox } from '@/app/components/ui/checkbox';
import { ScrollArea } from '@/app/components/ui/scroll-area';
import { useApp, Message } from '@/app/context/AppContext';
import {
  MessageSquare,
  Mail,
  Send,
  Users,
  History,
  Download,
  Filter,
  Search,
  CheckCircle,
  XCircle,
  Clock,
} from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

export function CommunicationCenter() {
  const { students, messages, sendMessage, currentUser } = useApp();
  const [messageType, setMessageType] = useState<'sms' | 'email'>('sms');
  const [recipients, setRecipients] = useState<string[]>([]);
  const [subject, setSubject] = useState('');
  const [content, setContent] = useState('');
  const [selectedGrade, setSelectedGrade] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectAll, setSelectAll] = useState(false);

  const activeStudents = students.filter((s) => s.status === 'Active' && !s.archived);
  const grades = ['all', 'Daycare', 'PP1', 'PP2', 'Grade 1', 'Grade 2', 'Grade 3', 'Grade 4', 'Grade 5', 'Grade 6'];

  const filteredStudents = activeStudents.filter((student) => {
    const matchesGrade = selectedGrade === 'all' || student.grade === selectedGrade;
    const matchesSearch =
      student.firstName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.lastName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      student.parentName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesGrade && matchesSearch;
  });

  const handleRecipientToggle = (contact: string) => {
    if (recipients.includes(contact)) {
      setRecipients(recipients.filter((r) => r !== contact));
    } else {
      setRecipients([...recipients, contact]);
    }
  };

  const handleSelectAll = () => {
    if (selectAll) {
      setRecipients([]);
    } else {
      const allContacts = filteredStudents.map((s) =>
        messageType === 'sms' ? s.parentPhone : s.parentEmail
      );
      setRecipients(allContacts);
    }
    setSelectAll(!selectAll);
  };

  const handleSendMessage = () => {
    if (recipients.length === 0) {
      toast.error('Please select at least one recipient');
      return;
    }
    if (!content.trim()) {
      toast.error('Please enter a message');
      return;
    }
    if (messageType === 'email' && !subject.trim()) {
      toast.error('Please enter an email subject');
      return;
    }

    recipients.forEach((recipient) => {
      const message: Message = {
        id: Date.now().toString() + recipient,
        type: messageType,
        recipient,
        subject: messageType === 'email' ? subject : undefined,
        content,
        sentDate: new Date().toISOString(),
        status: 'sent',
        sentBy: currentUser?.name || 'System',
      };
      sendMessage(message);
    });

    toast.success(`${messageType.toUpperCase()} sent to ${recipients.length} recipient(s)`);
    
    // Reset form
    setRecipients([]);
    setSubject('');
    setContent('');
    setSelectAll(false);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'delivered':
        return (
          <Badge className="bg-green-500 gap-1">
            <CheckCircle className="w-3 h-3" />
            Delivered
          </Badge>
        );
      case 'sent':
        return (
          <Badge className="bg-blue-500 gap-1">
            <CheckCircle className="w-3 h-3" />
            Sent
          </Badge>
        );
      case 'failed':
        return (
          <Badge variant="destructive" className="gap-1">
            <XCircle className="w-3 h-3" />
            Failed
          </Badge>
        );
      case 'pending':
        return (
          <Badge variant="outline" className="gap-1">
            <Clock className="w-3 h-3" />
            Pending
          </Badge>
        );
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const characterCount = content.length;
  const smsCount = Math.ceil(characterCount / 160);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl">Communication Center</h1>
          <p className="text-muted-foreground mt-1">
            Send SMS and emails to parents and guardians
          </p>
        </div>
        <Button variant="outline" className="gap-2">
          <Download className="w-4 h-4" />
          Export Contact List
        </Button>
      </div>

      <Tabs defaultValue="compose" className="space-y-4">
        <TabsList className="grid w-full grid-cols-3 lg:w-auto">
          <TabsTrigger value="compose" className="gap-2">
            <Send className="w-4 h-4" />
            Compose
          </TabsTrigger>
          <TabsTrigger value="history" className="gap-2">
            <History className="w-4 h-4" />
            History
          </TabsTrigger>
          <TabsTrigger value="contacts" className="gap-2">
            <Users className="w-4 h-4" />
            Contacts
          </TabsTrigger>
        </TabsList>

        <TabsContent value="compose" className="space-y-4">
          <div className="grid gap-4 lg:grid-cols-2">
            {/* Message Composition */}
            <Card>
              <CardHeader>
                <CardTitle>Compose Message</CardTitle>
                <CardDescription>
                  Create and send messages to parents
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Message Type */}
                <div className="space-y-2">
                  <Label>Message Type</Label>
                  <div className="flex gap-2">
                    <Button
                      variant={messageType === 'sms' ? 'default' : 'outline'}
                      onClick={() => setMessageType('sms')}
                      className="flex-1 gap-2"
                    >
                      <MessageSquare className="w-4 h-4" />
                      SMS
                    </Button>
                    <Button
                      variant={messageType === 'email' ? 'default' : 'outline'}
                      onClick={() => setMessageType('email')}
                      className="flex-1 gap-2"
                    >
                      <Mail className="w-4 h-4" />
                      Email
                    </Button>
                  </div>
                </div>

                {/* Recipients Count */}
                <div className="p-3 bg-secondary rounded-lg">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Recipients Selected</span>
                    <Badge>{recipients.length}</Badge>
                  </div>
                </div>

                {/* Email Subject */}
                {messageType === 'email' && (
                  <div className="space-y-2">
                    <Label>Subject *</Label>
                    <Input
                      placeholder="Enter email subject"
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                    />
                  </div>
                )}

                {/* Message Content */}
                <div className="space-y-2">
                  <Label>Message *</Label>
                  <Textarea
                    placeholder={
                      messageType === 'sms'
                        ? 'Enter SMS message (max 160 characters per SMS)'
                        : 'Enter email message'
                    }
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    rows={messageType === 'sms' ? 5 : 10}
                  />
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{characterCount} characters</span>
                    {messageType === 'sms' && (
                      <span>{smsCount} SMS {smsCount > 1 ? 'messages' : 'message'}</span>
                    )}
                  </div>
                </div>

                {/* Quick Templates */}
                <div className="space-y-2">
                  <Label>Quick Templates</Label>
                  <Select
                    onValueChange={(value) => {
                      if (value === 'fee_reminder') {
                        setContent(
                          'Dear parent, this is a reminder that school fees for Term 1 are due. Please ensure timely payment. Thank you.'
                        );
                      } else if (value === 'event_notice') {
                        setContent(
                          'Dear parent, we would like to inform you about an upcoming school event. More details will follow shortly.'
                        );
                      } else if (value === 'absence_notice') {
                        setContent(
                          'Dear parent, your child was absent from school today. Please ensure regular attendance. Contact us if there are any concerns.'
                        );
                      }
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a template" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fee_reminder">Fee Reminder</SelectItem>
                      <SelectItem value="event_notice">Event Notice</SelectItem>
                      <SelectItem value="absence_notice">Absence Notice</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Send Button */}
                <Button
                  onClick={handleSendMessage}
                  disabled={recipients.length === 0 || !content.trim()}
                  className="w-full gap-2"
                >
                  <Send className="w-4 h-4" />
                  Send {messageType === 'sms' ? 'SMS' : 'Email'} to {recipients.length} recipient(s)
                </Button>
              </CardContent>
            </Card>

            {/* Recipient Selection */}
            <Card>
              <CardHeader>
                <CardTitle>Select Recipients</CardTitle>
                <CardDescription>
                  Choose parents to receive the message
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Filters */}
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label>Filter by Grade</Label>
                    <Select value={selectedGrade} onValueChange={setSelectedGrade}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {grades.map((grade) => (
                          <SelectItem key={grade} value={grade}>
                            {grade === 'all' ? 'All Grades' : grade}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Search</Label>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        placeholder="Search parent..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-9"
                      />
                    </div>
                  </div>
                </div>

                {/* Select All */}
                <div className="flex items-center space-x-2 p-3 bg-secondary rounded-lg">
                  <Checkbox
                    id="select-all"
                    checked={selectAll}
                    onCheckedChange={handleSelectAll}
                  />
                  <label
                    htmlFor="select-all"
                    className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
                  >
                    Select all {filteredStudents.length} parents
                  </label>
                </div>

                {/* Parent List */}
                <ScrollArea className="h-[400px] border rounded-lg p-2">
                  <div className="space-y-2">
                    {filteredStudents.map((student) => {
                      const contact =
                        messageType === 'sms' ? student.parentPhone : student.parentEmail;
                      return (
                        <div
                          key={student.id}
                          className="flex items-start space-x-3 p-3 rounded-lg hover:bg-secondary transition-colors"
                        >
                          <Checkbox
                            id={student.id}
                            checked={recipients.includes(contact)}
                            onCheckedChange={() => handleRecipientToggle(contact)}
                          />
                          <label
                            htmlFor={student.id}
                            className="flex-1 cursor-pointer"
                          >
                            <div className="flex items-center justify-between">
                              <div>
                                <p className="font-medium text-sm">
                                  {student.parentName}
                                </p>
                                <p className="text-xs text-muted-foreground">
                                  Parent of {student.firstName} {student.lastName}
                                </p>
                                <p className="text-xs text-muted-foreground font-mono">
                                  {contact}
                                </p>
                              </div>
                              <Badge variant="outline">{student.grade}</Badge>
                            </div>
                          </label>
                        </div>
                      );
                    })}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Message History</CardTitle>
              <CardDescription>
                View all sent messages and delivery status
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Filters */}
              <div className="grid gap-4 md:grid-cols-3 mb-4">
                <div className="space-y-2">
                  <Label>Message Type</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="All types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="sms">SMS</SelectItem>
                      <SelectItem value="email">Email</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Status</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="All statuses" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="delivered">Delivered</SelectItem>
                      <SelectItem value="sent">Sent</SelectItem>
                      <SelectItem value="failed">Failed</SelectItem>
                      <SelectItem value="pending">Pending</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Search</Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input placeholder="Search messages..." className="pl-9" />
                  </div>
                </div>
              </div>

              {/* Messages Table */}
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Type</TableHead>
                      <TableHead>Recipient</TableHead>
                      <TableHead>Subject/Content</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Sent By</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {messages.length === 0 ? (
                      <TableRow>
                        <TableCell
                          colSpan={6}
                          className="text-center py-8 text-muted-foreground"
                        >
                          <MessageSquare className="w-12 h-12 mx-auto mb-2 opacity-50" />
                          <p>No messages sent yet</p>
                        </TableCell>
                      </TableRow>
                    ) : (
                      messages
                        .sort(
                          (a, b) =>
                            new Date(b.sentDate).getTime() -
                            new Date(a.sentDate).getTime()
                        )
                        .map((message) => (
                          <TableRow key={message.id}>
                            <TableCell>
                              <Badge
                                variant={
                                  message.type === 'sms' ? 'default' : 'outline'
                                }
                              >
                                {message.type === 'sms' ? (
                                  <MessageSquare className="w-3 h-3 mr-1" />
                                ) : (
                                  <Mail className="w-3 h-3 mr-1" />
                                )}
                                {message.type.toUpperCase()}
                              </Badge>
                            </TableCell>
                            <TableCell className="font-mono text-sm">
                              {message.recipient}
                            </TableCell>
                            <TableCell>
                              <div className="max-w-md">
                                {message.subject && (
                                  <div className="font-medium text-sm mb-1">
                                    {message.subject}
                                  </div>
                                )}
                                <p className="text-xs text-muted-foreground truncate">
                                  {message.content}
                                </p>
                              </div>
                            </TableCell>
                            <TableCell className="text-sm">
                              {format(new Date(message.sentDate), 'MMM dd, yyyy HH:mm')}
                            </TableCell>
                            <TableCell className="text-sm">
                              {message.sentBy}
                            </TableCell>
                            <TableCell>{getStatusBadge(message.status)}</TableCell>
                          </TableRow>
                        ))
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="contacts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Parent Contact List</CardTitle>
              <CardDescription>
                Complete list of parent contacts for all students
              </CardDescription>
            </CardHeader>
            <CardContent>
              {/* Filters */}
              <div className="grid gap-4 md:grid-cols-2 mb-4">
                <div className="space-y-2">
                  <Label>Filter by Grade</Label>
                  <Select value={selectedGrade} onValueChange={setSelectedGrade}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {grades.map((grade) => (
                        <SelectItem key={grade} value={grade}>
                          {grade === 'all' ? 'All Grades' : grade}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Search</Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      placeholder="Search contacts..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>
              </div>

              {/* Contacts Table */}
              <div className="border rounded-lg">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Parent Name</TableHead>
                      <TableHead>Student</TableHead>
                      <TableHead>Grade</TableHead>
                      <TableHead>Phone</TableHead>
                      <TableHead>Email</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredStudents.map((student) => (
                      <TableRow key={student.id}>
                        <TableCell className="font-medium">
                          {student.parentName}
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="text-sm">
                              {student.firstName} {student.lastName}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {student.admissionNumber}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline">{student.grade}</Badge>
                        </TableCell>
                        <TableCell className="font-mono text-sm">
                          {student.parentPhone}
                        </TableCell>
                        <TableCell className="text-sm">
                          {student.parentEmail}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
