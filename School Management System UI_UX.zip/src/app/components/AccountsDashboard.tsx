import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { useApp } from '@/app/context/AppContext';
import {
  Wallet,
  TrendingUp,
  TrendingDown,
  Users,
  FileText,
  Download,
  Plus,
  AlertCircle,
} from 'lucide-react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Badge } from '@/app/components/ui/badge';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/app/components/ui/table';
import { EmergencyAlerts, AnnouncementsWidget, AcademicCalendarWidget, FeeRemindersWidget } from '@/app/components/GlobalDashboardWidgets';

const revenueData = [
  { month: 'Jan', revenue: 4200000, expenses: 1500000 },
  { month: 'Feb', revenue: 4500000, expenses: 1600000 },
  { month: 'Mar', revenue: 4300000, expenses: 1550000 },
  { month: 'Apr', revenue: 4600000, expenses: 1700000 },
  { month: 'May', revenue: 4800000, expenses: 1650000 },
  { month: 'Jun', revenue: 5000000, expenses: 1750000 },
];

const paymentMethodData = [
  { name: 'M-Pesa', value: 65, color: '#22c55e' },
  { name: 'Bank Transfer', value: 25, color: '#3b82f6' },
  { name: 'Cash', value: 7, color: '#eab308' },
  { name: 'Cheque', value: 3, color: '#a855f7' },
];

export function AccountsDashboard() {
  const { feeRecords, students, setCurrentView } = useApp();

  const totalRevenue = feeRecords.reduce((sum, record) => sum + record.paidAmount, 0);
  const totalPending = feeRecords.reduce((sum, record) => sum + record.balance, 0);
  const collectionRate = totalRevenue / (totalRevenue + totalPending) * 100;

  const pendingPayments = feeRecords.filter((record) => record.balance > 0);

  return (
    <div className="space-y-6">
      <EmergencyAlerts />

      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl">Accounts Dashboard</h1>
          <p className="text-muted-foreground mt-1">
            Fee collection and financial overview
          </p>
        </div>
        <div className="flex gap-2">
          <Button onClick={() => setCurrentView('fees')} className="gap-2">
            <Plus className="w-4 h-4" />
            Record Payment
          </Button>
          <Button variant="outline" className="gap-2">
            <Download className="w-4 h-4" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardDescription>Total Revenue</CardDescription>
              <Wallet className="w-5 h-5 text-green-600" />
            </div>
          </CardHeader>
          <CardContent>
            <CardTitle className="text-2xl text-green-600">
              KSh {totalRevenue.toLocaleString()}
            </CardTitle>
            <div className="flex items-center gap-1 text-xs text-green-600 mt-2">
              <TrendingUp className="w-3 h-3" />
              <span>+12% from last term</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardDescription>Pending Fees</CardDescription>
              <AlertCircle className="w-5 h-5 text-red-600" />
            </div>
          </CardHeader>
          <CardContent>
            <CardTitle className="text-2xl text-red-600">
              KSh {totalPending.toLocaleString()}
            </CardTitle>
            <div className="flex items-center gap-1 text-xs text-muted-foreground mt-2">
              <span>{pendingPayments.length} students</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardDescription>Collection Rate</CardDescription>
              <TrendingUp className="w-5 h-5 text-blue-600" />
            </div>
          </CardHeader>
          <CardContent>
            <CardTitle className="text-2xl text-blue-600">
              {collectionRate.toFixed(1)}%
            </CardTitle>
            <div className="w-full bg-secondary rounded-full h-2 mt-2">
              <div
                className="bg-blue-600 h-2 rounded-full"
                style={{ width: `${collectionRate}%` }}
              />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardDescription>Active Students</CardDescription>
              <Users className="w-5 h-5 text-primary" />
            </div>
          </CardHeader>
          <CardContent>
            <CardTitle className="text-2xl">{students.length}</CardTitle>
            <div className="flex items-center gap-1 text-xs text-muted-foreground mt-2">
              <span>Enrolled this term</span>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {/* Revenue vs Expenses */}
        <Card>
          <CardHeader>
            <CardTitle>Revenue vs Expenses</CardTitle>
            <CardDescription>6-month financial overview</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={revenueData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip
                  formatter={(value: number) => `KSh ${value.toLocaleString()}`}
                />
                <Legend />
                <Bar dataKey="revenue" fill="#22c55e" name="Revenue" />
                <Bar dataKey="expenses" fill="#ef4444" name="Expenses" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Payment Methods */}
        <Card>
          <CardHeader>
            <CardTitle>Payment Methods Distribution</CardTitle>
            <CardDescription>How parents are paying fees</CardDescription>
          </CardHeader>
          <CardContent className="flex items-center justify-center">
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={paymentMethodData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}%`}
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {paymentMethodData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Recent Pending Payments */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Pending Payments</CardTitle>
          <CardDescription>Students with outstanding fee balances</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Student</TableHead>
                <TableHead>Grade</TableHead>
                <TableHead>Total Fees</TableHead>
                <TableHead>Paid</TableHead>
                <TableHead>Balance</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {pendingPayments.slice(0, 5).map((record) => {
                const student = students.find((s) => s.id === record.studentId);
                return (
                  <TableRow key={record.id}>
                    <TableCell>
                      <div>
                        <div className